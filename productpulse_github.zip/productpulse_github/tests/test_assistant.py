"""Run with:  pytest -q   (needs the pipeline to have been run once)"""
import os

import pytest

os.environ["PP_DISABLE_LLM"] = "1"
from src import config  # noqa: E402

pytestmark = pytest.mark.skipif(not config.DB_PATH.exists(), reason="run `python run_pipeline.py` first")


def test_routing_accuracy_above_90pct():
    from src.assistant.evaluate import run
    assert run(use_llm=False, verbose=False)["accuracy"] >= 0.90


def test_sql_guard_blocks_writes():
    from src.assistant.sql_guard import safe_sql
    for bad in ["DROP TABLE customers", "DELETE FROM customers", "SELECT 1; DROP TABLE x", "UPDATE customers SET churned=0"]:
        with pytest.raises(ValueError):
            safe_sql(bad)
    assert safe_sql("select * from customers").endswith("LIMIT 200")


def test_db_is_read_only():
    import sqlite3
    from src.db import get_conn
    with pytest.raises(sqlite3.OperationalError):
        get_conn().execute("DELETE FROM customers")


def test_no_leaky_columns_in_features():
    import pandas as pd
    from src.db import get_conn
    from src.features import LEAKY_COLUMNS
    cols = pd.read_sql_query("SELECT * FROM features LIMIT 1", get_conn()).columns
    assert not set(LEAKY_COLUMNS) & set(cols)
