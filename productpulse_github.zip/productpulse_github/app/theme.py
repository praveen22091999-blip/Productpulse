"""Visual theme: soft lavender canvas, white rounded cards, indigo accent (inspired by modern SaaS dashboards)."""
import streamlit as st

PRIMARY, PURPLE, GREEN, RED, ORANGE, SKY = "#4B5EFC", "#8B5CF6", "#22C55E", "#EF4444", "#F59E0B", "#38BDF8"
INK, MUTED, GRID = "#1E2140", "#8A8FAE", "#EEF0F8"
PALETTE = [PRIMARY, PURPLE, "#34D399", ORANGE, "#F472B6", SKY]

from urllib.parse import quote

ICON_PATHS = {
    "grid": "<rect x='3' y='3' width='7' height='7' rx='1.5'/><rect x='14' y='3' width='7' height='7' rx='1.5'/><rect x='3' y='14' width='7' height='7' rx='1.5'/><rect x='14' y='14' width='7' height='7' rx='1.5'/>",
    "bars": "<path d='M4 20V11M10 20V4M16 20v-6M2 21h20'/>",
    "shield": "<path d='M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z'/><path d='M12 9v4M12 16.5v.01'/>",
    "user_search": "<circle cx='9' cy='8' r='4'/><path d='M2 21c0-4 3-7 7-7'/><circle cx='17' cy='17' r='3'/><path d='M22 22l-2.5-2.5'/>",
    "pie": "<path d='M21 12A9 9 0 1 1 12 3v9z'/><path d='M15 3.5A9 9 0 0 1 20.5 9H15z'/>",
    "bulb": "<path d='M9 18h6M10 21h4'/><path d='M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0 0 12 3z'/>",
    "cpu": "<rect x='5' y='5' width='14' height='14' rx='2'/><rect x='9' y='9' width='6' height='6'/><path d='M9 1v4M15 1v4M9 19v4M15 19v4M1 9h4M1 15h4M19 9h4M19 15h4'/>",
    "chat": "<path d='M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z'/>",
    "users": "<circle cx='9' cy='8' r='3.5'/><path d='M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6'/><path d='M16 4.5a3.5 3.5 0 0 1 0 7M18 14c2.2.6 3.5 2.4 3.5 5'/>",
    "trend_down": "<path d='M3 7l6 6 4-4 8 8'/><path d='M15 17h6v-6'/>",
    "dollar": "<path d='M12 2v20'/><path d='M17 6.5C16 5 14.3 4.5 12 4.5c-2.8 0-4.5 1.2-4.5 3s1.7 2.7 4.5 3.2 4.5 1.4 4.5 3.3-1.8 3-4.5 3c-2.4 0-4.2-.7-5.2-2.3'/>",
    "alert": "<path d='M12 3l10 18H2z'/><path d='M12 10v5M12 18v.01'/>",
    "flag": "<path d='M5 21V4M5 4h12l-2 4 2 4H5'/>",
    "target": "<circle cx='12' cy='12' r='9'/><circle cx='12' cy='12' r='5'/><circle cx='12' cy='12' r='1'/>",
    "phone": "<path d='M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z'/>",
    "flame": "<path d='M12 3c1 4 5 5.5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-5 1-9z'/>",
    "lifebuoy": "<circle cx='12' cy='12' r='9'/><circle cx='12' cy='12' r='3.5'/><path d='M5.6 5.6l3.9 3.9M14.5 14.5l3.9 3.9M18.4 5.6l-3.9 3.9M9.5 14.5l-3.9 3.9'/>",
    "check": "<circle cx='12' cy='12' r='9'/><path d='M8 12.5l3 3 5-6'/>",
    "chart": "<path d='M3 3v18h18'/><path d='M7 15l4-5 3 3 5-6'/>",
    "search": "<circle cx='11' cy='11' r='7'/><path d='M21 21l-4.5-4.5'/>",
    "rocket": "<path d='M5 15c-1 1-1.5 4-1.5 4s3-.5 4-1.5'/><path d='M12 15l-3-3c1-4 4-8 11-9 0 7-4 10-8 12z'/><circle cx='15.5' cy='8.5' r='1.5'/>",
}
NAV_ICON = {"overview": "grid", "adoption": "bars", "risk": "shield", "customer": "user_search",
            "segments": "pie", "opportunities": "bulb", "model": "cpu", "assistant": "chat"}


def _svg_url(inner: str, color: str) -> str:
    svg = (f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='{color}' "
           f"stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'>{inner}</svg>")
    return 'url("data:image/svg+xml,' + quote(svg) + '")'


def icon_css() -> str:
    out = []
    for name, inner in ICON_PATHS.items():
        out.append(f".ico-{name}{{background-image:{_svg_url(inner, PRIMARY)};}}")
        out.append(f".kpi.featured .ico-{name}{{background-image:{_svg_url(inner, 'white')};}}")
    for key, name in NAV_ICON.items():
        out.append(f".st-key-nav_{key} button::before{{background-image:{_svg_url(ICON_PATHS[name], 'white')};}}")
    return "\n".join(out)


CSS = """
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
.stApp { font-family:'Inter',sans-serif; background:#F4F5FB; color:#1E2140; }
header[data-testid="stHeader"] { background:transparent; }
#MainMenu, footer { visibility:hidden; }
.block-container { padding-top:1.6rem; padding-bottom:3rem; max-width:1440px; }
h1,h2,h3 { color:#1E2140; letter-spacing:-0.01em; }

/* ---------- sidebar (deep purple, inspired by the reference) ---------- */
section[data-testid="stSidebar"], section[data-testid="stSidebar"] > div:first-child {
  background:linear-gradient(180deg,#5B21B6 0%,#4C1D95 60%,#3B1680 100%); border-right:none; }
[data-testid="stSidebar"][aria-expanded="true"] { min-width:292px; max-width:292px; }
section[data-testid="stSidebar"] .block-container, section[data-testid="stSidebarUserContent"] { padding-top:1.4rem; }
[data-testid="stSidebarCollapseButton"] button, [data-testid="stSidebarCollapseButton"] svg { color:#fff !important; fill:#fff; }
.brand { display:flex; align-items:center; gap:12px; margin:4px 0 26px 4px; }
.brand-logo { width:38px; height:38px; border-radius:12px; display:flex; align-items:center; justify-content:center;
  color:#4C1D95; font-weight:800; font-size:20px; background:#fff; box-shadow:0 8px 20px rgba(0,0,0,.25); }
.brand-name { font-weight:800; font-size:21px; color:#fff; letter-spacing:-0.01em; }
section[data-testid="stSidebar"] [data-testid="stElementContainer"], section[data-testid="stSidebar"] .stButton { width:100%; }
section[data-testid="stSidebar"] .stButton { margin-bottom:-6px; }
section[data-testid="stSidebar"] .stButton button {
  width:100%; display:flex; justify-content:flex-start; align-items:center; gap:14px;
  padding:13px 14px; border-radius:14px; border:none !important; outline:none !important; box-shadow:none !important;
  background:transparent !important; color:#fff !important; transition:background .15s; }
section[data-testid="stSidebar"] .stButton button > div { flex:1; text-align:left; }
section[data-testid="stSidebar"] .stButton button p { color:#fff !important; font-size:15.5px; font-weight:600; margin:0; text-align:left; }
section[data-testid="stSidebar"] .stButton button::before { content:""; flex:0 0 22px; height:22px; background-repeat:no-repeat;
  background-position:center; background-size:contain; }
section[data-testid="stSidebar"] .stButton button::after { content:"\\2192"; margin-left:auto; color:#fff; opacity:.7; font-size:18px; }
section[data-testid="stSidebar"] .stButton button:hover { background:rgba(255,255,255,.09) !important; }
section[data-testid="stSidebar"] .stButton button[kind="primary"],
section[data-testid="stSidebar"] .stButton button[data-testid="stBaseButton-primary"] { background:rgba(255,255,255,.17) !important; }
.side-head { display:flex; justify-content:space-between; align-items:center; margin:30px 4px 12px 4px; color:#fff; font-weight:700; font-size:15px; }
.side-badge { background:rgba(255,255,255,.18); border-radius:10px; padding:4px 12px; font-size:13px; font-weight:700; color:#fff; }
.alert-row { display:flex; align-items:center; gap:12px; padding:8px 4px; }
.avatar { width:38px; height:38px; border-radius:50%; background:linear-gradient(135deg,#C4B5FD,#8B5CF6); color:#2E1065;
  display:flex; align-items:center; justify-content:center; font-weight:800; font-size:13px; flex:0 0 38px; }
.alert-name { color:#fff; font-weight:700; font-size:14px; line-height:1.2; }
.alert-sub { color:#D8CCFF; font-size:12.5px; }
.dot { width:9px; height:9px; border-radius:50%; margin-left:auto; flex:0 0 9px; }
.dot.red { background:#F87171; } .dot.amber { background:#FBBF24; }
.side-foot { margin-top:18px; padding:14px 16px; border-radius:16px; background:rgba(255,255,255,.10); color:#fff; }
.side-foot .t { font-weight:700; font-size:14px; } .side-foot .d { font-size:12.5px; color:#D8CCFF; margin-top:3px; line-height:1.5; }

/* ---------- page header ---------- */
.page-title { font-size:28px; font-weight:800; color:#1E2140; line-height:1.15; }
.page-sub { font-size:14px; color:#8A8FAE; margin-top:4px; margin-bottom:1.2rem; }
.chip { display:inline-block; float:right; padding:8px 14px; border-radius:999px; background:#fff; color:#4B5EFC;
  font-weight:600; font-size:13px; box-shadow:0 4px 14px rgba(75,94,252,.10); }

/* ---------- KPI cards ---------- */
.kpi { background:#fff; border-radius:20px; padding:18px 20px; box-shadow:0 6px 22px rgba(30,33,64,.06); height:100%; min-height:138px; }
.kpi-top { display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; }
.kpi-icon { width:40px; height:40px; border-radius:12px; background-color:#EEF0FF; background-repeat:no-repeat; background-position:center; background-size:21px; }
.kpi-label { font-size:13px; color:#8A8FAE; font-weight:500; }
.kpi-value { font-size:28px; font-weight:800; color:#1E2140; line-height:1.2; margin-top:2px; }
.kpi-sub { font-size:12px; color:#8A8FAE; margin-top:4px; }
.kpi.featured { background:linear-gradient(135deg,#4B5EFC 0%,#6D5BF6 100%); box-shadow:0 14px 30px rgba(75,94,252,.35); }
.kpi.featured .kpi-label, .kpi.featured .kpi-sub { color:#DCE0FF; }
.kpi.featured .kpi-value { color:#fff; }
.kpi.featured .kpi-icon { background-color:rgba(255,255,255,.2); }
.pill { font-size:12px; font-weight:700; padding:4px 10px; border-radius:999px; }
.pill.green { background:#DCFCE7; color:#15803D; } .pill.red { background:#FEE2E2; color:#B91C1C; }
.pill.blue { background:#E0E7FF; color:#4338CA; } .pill.amber { background:#FEF3C7; color:#B45309; }
.kpi.featured .pill { background:rgba(255,255,255,.22); color:#fff; }

/* ---------- generic cards ---------- */
.card { background:#fff; border-radius:20px; padding:18px 20px; box-shadow:0 6px 22px rgba(30,33,64,.06); margin-bottom:6px; height:100%; }
.card h4 { margin:0 0 6px 0; font-size:16px; font-weight:700; color:#1E2140; }
.card .meta { font-size:12.5px; color:#6B7094; line-height:1.55; }
.callout { background:#EEF0FF; border-left:4px solid #4B5EFC; border-radius:12px; padding:12px 16px; font-size:14px; color:#1E2140; margin:8px 0; }
.callout.warn { background:#FFF4E5; border-left-color:#F59E0B; }
.section-title { font-size:17px; font-weight:700; margin:1.4rem 0 .6rem 0; color:#1E2140; }

/* ---------- charts / tables / inputs ---------- */
div[data-testid="stPlotlyChart"], div[data-testid="stDataFrame"] { background:#fff; border-radius:20px; padding:10px 12px; box-shadow:0 6px 22px rgba(30,33,64,.06); }
.stButton > button, .stDownloadButton > button { border-radius:12px; border:1px solid #E3E6F5; background:#fff; color:#1E2140; font-weight:600; }
.stButton > button:hover, .stDownloadButton > button:hover { border-color:#4B5EFC; color:#4B5EFC; }
div[data-baseweb="select"] > div, .stTextInput input { border-radius:12px !important; }
[data-testid="stChatMessage"] { background:#fff; border-radius:18px; box-shadow:0 4px 16px rgba(30,33,64,.05); margin-bottom:10px; }
"""


def inject_css():
    st.markdown(f"<style>{CSS}\n{icon_css()}</style>", unsafe_allow_html=True)


def html(s: str):
    """Render HTML safely: strip indentation so markdown does not treat it as a code block."""
    st.markdown("\n".join(l.strip() for l in s.strip().splitlines() if l.strip()), unsafe_allow_html=True)


def kpi_card(label, value, sub="", pill="", kind="blue", icon="chart", featured=False):
    pill_html = f'<span class="pill {kind}">{pill}</span>' if pill else ""
    return (f'<div class="kpi {"featured" if featured else ""}"><div class="kpi-top">'
            f'<div class="kpi-icon ico-{icon}"></div>{pill_html}</div>'
            f'<div class="kpi-label">{label}</div><div class="kpi-value">{value}</div>'
            f'<div class="kpi-sub">{sub}</div></div>')


def style_fig(fig, title="", height=340):
    fig.update_layout(
        title=dict(text=title, x=0.02, font=dict(size=16, color=INK)),
        height=height, margin=dict(l=16, r=16, t=56, b=16),
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font=dict(family="Inter, sans-serif", color=MUTED, size=12),
        legend=dict(orientation="h", y=-0.18, x=0, title_text=""),
        colorway=PALETTE,
    )
    fig.update_xaxes(showgrid=False, linecolor=GRID, title_text="")
    fig.update_yaxes(gridcolor=GRID, zeroline=False, title_text="")
    return fig
