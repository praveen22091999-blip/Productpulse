"""ProductPulse dashboard.  Run:  streamlit run app/dashboard.py"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

st.set_page_config(page_title="ProductPulse", page_icon="chart", layout="wide")

from app.theme import (GREEN, INK, ORANGE, PRIMARY, PURPLE, RED, SKY,  # noqa: E402
                       html, inject_css, kpi_card, style_fig)
from src import config  # noqa: E402
from src.db import get_conn, run_query  # noqa: E402
from src.explain import describe, pretty  # noqa: E402

inject_css()

if not config.DB_PATH.exists() or not config.METRICS_PATH.exists():
    st.error("Database not found. Run `python run_pipeline.py` first, then reload this page.")
    st.stop()

METRICS = json.loads(config.METRICS_PATH.read_text())
OOF = METRICS["xgboost_cv_oof"]
TENURE_ORDER = ["0-6 mo", "7-12 mo", "13-24 mo", "25-48 mo", "49-72 mo"]


# ------------------------------------------------------------------ data access (cached)
@st.cache_data(show_spinner=False)
def Q(name, **params):
    return run_query(name, params or None)


@st.cache_data(show_spinner=False)
def T(sql, **params):
    con = get_conn()
    try:
        return pd.read_sql_query(sql, con, params=params or {})
    finally:
        con.close()


@st.cache_resource(show_spinner=False)
def get_assistant():
    from src.assistant.router import Assistant
    return Assistant()


def header(title, sub):
    a, b = st.columns([3, 1.3])
    with a:
        html(f'<div class="page-title">{title}</div><div class="page-sub">{sub}</div>')
    with b:
        html(f'<div class="chip">XGBoost · ROC-AUC {OOF["roc_auc"]:.2f}</div>')


def section(text):
    html(f'<div class="section-title">{text}</div>')


# ------------------------------------------------------------------ pages
def page_overview():
    header("Executive Overview", "Churn, revenue and risk at a glance")
    k = Q("kpi_overview").iloc[0]
    risk = Q("mrr_at_risk_by_contract")
    mrr_risk, n_hi = risk["mrr_at_risk"].sum(), int(risk["high_risk_customers"].sum())

    c = st.columns(4)
    with c[0]:
        html(kpi_card("Total customers", f"{int(k.customers):,}", f"avg tenure {k.avg_tenure_months} months",
                      "snapshot", icon="users", featured=True))
    with c[1]:
        html(kpi_card("Churn rate", f"{k.churn_rate_pct}%", f"{int(k.churned_customers):,} customers lost",
                      "needs action", "red", icon="trend_down"))
    with c[2]:
        html(kpi_card("Active MRR", f"${k.active_mrr:,.0f}", f"${k.lost_mrr:,.0f} MRR already lost",
                      "recurring", "green", icon="dollar"))
    with c[3]:
        html(kpi_card("MRR at risk", f"${mrr_risk:,.0f}", f"{n_hi:,} active customers with risk >= 50%",
                      "predicted", "amber", icon="alert"))

    section("Where is churn coming from?")
    a, b = st.columns([2, 1])
    with a:
        df = Q("churn_by_contract")
        fig = px.bar(df, x="contract", y="churn_rate_pct", text="churn_rate_pct", color_discrete_sequence=[PRIMARY])
        fig.update_traces(texttemplate="%{text}%", textposition="outside")
        fig.update_yaxes(range=[0, df["churn_rate_pct"].max() * 1.25])
        st.plotly_chart(style_fig(fig, "Churn rate by contract type (%)"))
    with b:
        active = int(k.customers - k.churned_customers)
        fig = go.Figure(go.Pie(labels=["Active", "Churned"], values=[active, int(k.churned_customers)], hole=0.72,
                               marker=dict(colors=[PRIMARY, "#F87171"]), textinfo="none", sort=False))
        fig.add_annotation(text=f"<b>{k.churn_rate_pct}%</b><br>churned", showarrow=False,
                           font=dict(size=20, color=INK))
        st.plotly_chart(style_fig(fig, "Customer base"))

    a, b = st.columns(2)
    with a:
        df = Q("churn_by_tenure_band")
        fig = go.Figure(go.Scatter(x=df["tenure_band"], y=df["churn_rate_pct"], mode="lines+markers",
                                   line=dict(color=PURPLE, width=3, shape="spline"), fill="tozeroy",
                                   fillcolor="rgba(139,92,246,0.12)", marker=dict(size=9)))
        st.plotly_chart(style_fig(fig, "Churn rate by tenure (%) - early life is the danger zone"))
    with b:
        df = Q("top_churn_reasons").head(8).iloc[::-1]
        fig = px.bar(df, x="customers_lost", y="churn_reason", orientation="h", color_discrete_sequence=[PRIMARY])
        st.plotly_chart(style_fig(fig, "Top reasons customers gave for leaving"))

    a, b = st.columns(2)
    with a:
        df = Q("churn_by_segment")
        fig = px.bar(df, x="segment", y="churn_rate_pct", text="churn_rate_pct", color="churn_rate_pct",
                     color_continuous_scale=["#C7D2FE", PRIMARY, "#312E81"])
        fig.update_traces(texttemplate="%{text}%", textposition="outside")
        fig.update_layout(coloraxis_showscale=False)
        st.plotly_chart(style_fig(fig, "Churn rate by customer segment (%)"))
    with b:
        fig = px.bar(risk, x="contract", y="mrr_at_risk", text="mrr_at_risk", color_discrete_sequence=[ORANGE])
        fig.update_traces(texttemplate="$%{text:,.0f}", textposition="outside")
        st.plotly_chart(style_fig(fig, "Monthly revenue at risk by contract ($)"))


def page_adoption():
    header("Adoption & Retention", "Which features and behaviours keep customers?")
    df = Q("addon_adoption_vs_churn")
    a, b = st.columns([3, 2])
    with a:
        fig = px.bar(df, x="feature", y="churn_rate_pct", color="has_feature", barmode="group",
                     color_discrete_map={"Yes": GREEN, "No": RED}, text="churn_rate_pct")
        fig.update_traces(texttemplate="%{text}%", textposition="outside")
        st.plotly_chart(style_fig(fig, "Churn rate: customers WITH vs WITHOUT each feature (%)", 380))
    with b:
        p = df.pivot(index="feature", columns="has_feature", values="customers").fillna(0)
        adoption = (100 * p.get("Yes", 0) / (p.get("Yes", 0) + p.get("No", 0))).round(1).sort_values()
        fig = px.bar(x=adoption.values, y=adoption.index, orientation="h", color_discrete_sequence=[PURPLE])
        st.plotly_chart(style_fig(fig, "Feature adoption among internet customers (%)", 380))
    html('<div class="callout">Customers who use protection/support features churn far less. '
         'This is a <b>correlation</b>: engaged customers may adopt more. Validate with an A/B pilot before big bets.</div>')

    a, b = st.columns(2)
    with a:
        d = Q("churn_by_contract_tenure")
        fig = px.line(d, x="tenure_band", y="churn_rate_pct", color="contract", markers=True,
                      category_orders={"tenure_band": TENURE_ORDER})
        st.plotly_chart(style_fig(fig, "Retention curve: churn % by tenure within each contract"))
    with b:
        d = Q("churn_by_contract_payment")
        pv = d.pivot(index="contract", columns="payment_method", values="churn_rate_pct")
        fig = go.Figure(go.Heatmap(z=pv.values, x=[c.replace(" (automatic)", "") for c in pv.columns], y=list(pv.index),
                                   colorscale=[[0, "#EEF2FF"], [1, PRIMARY]], texttemplate="%{z}%",
                                   showscale=False))
        st.plotly_chart(style_fig(fig, "Churn % - contract x payment method"))

    a, b = st.columns(2)
    with a:
        d = Q("churn_by_internet")
        fig = px.bar(d, x="internet_service", y="churn_rate_pct", text="churn_rate_pct", color_discrete_sequence=[SKY])
        fig.update_traces(texttemplate="%{text}%", textposition="outside")
        st.plotly_chart(style_fig(fig, "Churn % by internet service"))
    with b:
        d = Q("churn_by_monthly_charge")
        fig = px.bar(d, x="price_band", y="churn_rate_pct", text="churn_rate_pct", color_discrete_sequence=[ORANGE])
        fig.update_traces(texttemplate="%{text}%", textposition="outside")
        st.plotly_chart(style_fig(fig, "Churn % by monthly price band"))


def page_risk():
    header("Churn Risk", "Active customers ranked by predicted churn probability")
    df = Q("active_risk_list")
    f = st.columns(3)
    contracts = f[0].multiselect("Contract", sorted(df["contract"].unique()))
    segs = f[1].multiselect("Segment", sorted(df["segment"].unique()))
    min_risk = f[2].slider("Minimum risk score", 0.0, 1.0, 0.5, 0.05)
    view = df[df["risk_score"] >= min_risk]
    if contracts:
        view = view[view["contract"].isin(contracts)]
    if segs:
        view = view[view["segment"].isin(segs)]

    c = st.columns(3)
    with c[0]:
        html(kpi_card("Customers flagged", f"{len(view):,}", f"of {len(df):,} active customers", icon="flag",
                      featured=True))
    with c[1]:
        html(kpi_card("Monthly revenue at risk", f"${view['monthly_charges'].sum():,.0f}", "sum of their bills",
                      icon="dollar"))
    with c[2]:
        html(kpi_card("Average risk", f"{view['risk_score'].mean():.0%}" if len(view) else "-", "in this view",
                      icon="target"))

    section("Ranked customer list")
    st.dataframe(view[["customer_id", "risk_score", "segment", "contract", "tenure_months", "monthly_charges",
                       "plain_text_reason", "recommended_action"]].head(500),
                 hide_index=True,
                 column_config={"risk_score": st.column_config.ProgressColumn("Risk", min_value=0, max_value=1,
                                                                              format="%.2f"),
                                "monthly_charges": st.column_config.NumberColumn("Monthly $", format="$%.2f"),
                                "plain_text_reason": "Why", "recommended_action": "Recommended action"})
    st.download_button("Download this list (CSV)", view.to_csv(index=False), "at_risk_customers.csv", "text/csv")

    section("Retention campaign simulator")
    s = st.columns(3)
    pct = s[0].slider("Contact the top X% riskiest customers", 1, 50, int(config.TOP_PCT_CONTACTED * 100))
    save = s[1].slider("Save rate (share of would-be churners retained)", 0.05, 0.8, config.SAVE_RATE, 0.05)
    cost = s[2].number_input("Cost per contact ($)", 0.0, 500.0, float(config.CONTACT_COST), 5.0)
    k = max(1, int(len(df) * pct / 100))
    top = df.head(k)
    exp_churners = top["risk_score"].sum()
    saved = (top["risk_score"] * top["annual_revenue"]).sum() * save
    net = saved - k * cost
    m = st.columns(4)
    for col, (lab, val, sub, ic) in zip(m, [
            ("Customers contacted", f"{k:,}", f"top {pct}% by risk", "phone"),
            ("Expected churners in group", f"{exp_churners:,.0f}", "sum of risk scores", "flame"),
            ("Expected revenue saved", f"${saved:,.0f}", "annual, at chosen save rate", "lifebuoy"),
            ("Net value", f"${net:,.0f}", f"after ${k * cost:,.0f} campaign cost", "check")]):
        with col:
            html(kpi_card(lab, val, sub, icon=ic, featured=(lab == "Net value")))
    st.caption("Expected-value estimate using model risk scores as churn probabilities. "
               "Assumptions are adjustable above; they are not guaranteed results.")


def page_customer():
    header("Customer Drill-down", "Why is this customer at risk, and what should we do?")
    df = Q("active_risk_list")
    a, b = st.columns(2)
    pick = a.selectbox("Pick one of the 300 riskiest active customers", df["customer_id"].head(300).tolist())
    typed = b.text_input("...or type any customer ID", "", placeholder="e.g. 7590-VHVEG")
    cid = typed.strip().upper() or pick
    r = Q("customer_lookup", cid=cid)
    if r.empty:
        st.warning(f"Customer {cid} not found.")
        return
    r = r.iloc[0]
    risk = float(r.risk_score)
    color = RED if risk >= config.HIGH_RISK else ORANGE if risk >= config.MEDIUM_RISK else GREEN

    a, b = st.columns([1, 2])
    with a:
        fig = go.Figure(go.Indicator(
            mode="gauge+number", value=risk * 100, number=dict(suffix="%", font=dict(size=40, color=INK)),
            gauge=dict(axis=dict(range=[0, 100]), bar=dict(color=color, thickness=0.3),
                       steps=[dict(range=[0, 30], color="#DCFCE7"), dict(range=[30, 60], color="#FEF3C7"),
                              dict(range=[60, 100], color="#FEE2E2")])))
        st.plotly_chart(style_fig(fig, f"Churn risk - {r.risk_band}", 280))
        html(f'<div class="card"><h4>{r.customer_id}</h4><div class="meta">Status: <b>{r.status}</b><br>'
             f'Segment: <b>{r.segment}</b><br>Contract: {r.contract}<br>Internet: {r.internet_service}<br>'
             f'Tenure: {r.tenure_months} months<br>Bill: ${r.monthly_charges:.2f}/month</div></div>')
    with b:
        sv = T("SELECT * FROM shap_values WHERE customer_id = :c", c=cid).iloc[0].drop("customer_id").astype(float)
        fv = T("SELECT * FROM features WHERE customer_id = :c", c=cid).iloc[0].drop("customer_id").astype(float)
        top = sv.reindex(sv.abs().sort_values(ascending=False).index)[:8].iloc[::-1]
        fig = go.Figure(go.Bar(x=top.values, y=[describe(c, fv[c]) for c in top.index], orientation="h",
                               marker_color=[RED if v > 0 else GREEN for v in top.values]))
        style_fig(fig, "What drives this customer's score", 400)
        fig.update_xaxes(title_text="SHAP impact on churn (log-odds): red raises risk, green lowers it")
        st.plotly_chart(fig)
        html(f'<div class="callout"><b>Why:</b> {r.plain_text_reason}</div>')
        if r.protective_factor:
            html(f'<div class="callout" style="background:#ECFDF5;border-left-color:#22C55E"><b>Keeping them:</b> '
                 f'{r.protective_factor}</div>')
        html(f'<div class="callout warn"><b>Recommended action:</b> {r.recommended_action}</div>')


def page_segments():
    header("Customer Segments", "K-Means clusters on tenure, spend, add-ons, contract and fiber usage")
    prof = T("SELECT * FROM segment_profiles ORDER BY churn_rate_pct DESC")
    for i in range(0, len(prof), 3):
        cols = st.columns(3)
        for col, (_, p) in zip(cols, prof.iloc[i:i + 3].iterrows()):
            kind = "red" if p.churn_rate_pct >= 30 else "amber" if p.churn_rate_pct >= 15 else "green"
            with col:
                html(f'<div class="card"><div style="display:flex;justify-content:space-between;align-items:center">'
                     f'<h4>{p.segment}</h4><span class="pill {kind}">{p.churn_rate_pct}% churn</span></div>'
                     f'<div class="meta">{int(p.customers):,} customers ({p.share_pct}%)<br>'
                     f'${p.avg_monthly_charges:.0f}/mo · {p.avg_tenure_months:.0f} mo tenure · {p.avg_addons:.1f} add-ons<br>'
                     f'{p.pct_month_to_month:.0f}% month-to-month · {p.pct_fiber:.0f}% fiber<br>'
                     f'MRR at risk: <b>${p.mrr_at_risk:,.0f}</b></div></div>')
    a, b = st.columns([3, 2])
    with a:
        pts = Q("segment_points")
        pts = pts.sample(min(2500, len(pts)), random_state=1)
        fig = px.scatter(pts, x="tenure_months", y="monthly_charges", color="segment", opacity=0.65)
        st.plotly_chart(style_fig(fig, "Segments: tenure vs monthly charges", 420))
    with b:
        fig = px.bar(prof.sort_values("mrr_at_risk"), x="mrr_at_risk", y="segment", orientation="h",
                     color_discrete_sequence=[ORANGE])
        st.plotly_chart(style_fig(fig, "MRR at risk by segment ($)", 420))
    k = T("SELECT * FROM segment_k_scores")
    st.caption(f"Cluster count chosen by silhouette score among k = {int(k.k.min())}-{int(k.k.max())}: "
               + ", ".join(f"k={int(r.k)}: {r.silhouette:.3f}" for _, r in k.iterrows()))


def page_opportunities():
    header("Product Opportunities", "Where would a retention or product push pay off most?")
    opp = T("SELECT * FROM opportunities ORDER BY est_annual_revenue_impact DESC")
    seg = st.selectbox("Segment", ["All segments"] + sorted(opp["segment"].unique()))
    view = opp if seg == "All segments" else opp[opp["segment"] == seg]
    for _, r in view.head(3).iterrows():
        html(f'<div class="callout"><b>#{int(r["rank"])} {r.lever} - {r.segment}</b><br>{r.insight}</div>')
    top = view.head(10).copy()
    top["label"] = top["segment"] + " · " + top["lever"]
    fig = px.bar(top.iloc[::-1], x="est_annual_revenue_impact", y="label", orientation="h",
                 color_discrete_sequence=[PRIMARY])
    st.plotly_chart(style_fig(fig, "Estimated annual revenue impact ($)", 420))
    st.dataframe(view[["rank", "segment", "lever", "adoption_rate_pct", "churn_with_pct", "churn_without_pct",
                       "churn_gap_pp", "addressable_active_customers", "est_customers_retained",
                       "est_annual_revenue_impact"]], hide_index=True)
    st.caption(f"Assumes {int(config.ADOPTION_CONVERSION * 100)}% of active non-adopters can be converted. "
               "Churn gaps are observational (correlation), so treat impacts as hypotheses to A/B test.")


def page_model():
    header("Model Performance", "Honest evaluation of the churn model")
    c = st.columns(4)
    for col, (lab, val, sub, ic) in zip(c, [
            ("ROC-AUC", f"{OOF['roc_auc']:.3f}", "5-fold out-of-fold", "chart"),
            ("PR-AUC", f"{OOF['pr_auc']:.3f}", f"baseline ≈ {METRICS['meta']['churn_rate']:.2f}", "target"),
            ("Recall @ top 10%", f"{OOF['recall_at_top10']:.0%}", "share of churners captured", "search"),
            ("Lift @ top 10%", f"{OOF['lift_at_top10']:.1f}x", "vs random targeting", "rocket")]):
        with col:
            html(kpi_card(lab, val, sub, icon=ic, featured=(lab == "ROC-AUC")))

    section("Model comparison (20% hold-out)")
    comp = pd.DataFrame({k: METRICS[k] for k in ["logistic_regression", "xgboost"]}).T.round(3)
    st.dataframe(comp)
    bv = METRICS.get("business_value_holdout")
    if bv:
        html(f'<div class="callout"><b>Back-test:</b> contacting the top 10% riskiest customers '
             f'({bv["customers_contacted"]:,} in the hold-out) would save about <b>${bv["revenue_saved"]:,.0f}</b> '
             f'of annual revenue for ${bv["campaign_cost"]:,.0f} of campaign cost - net <b>${bv["net_value"]:,.0f}</b> '
             f'(assuming a {int(config.SAVE_RATE * 100)}% save rate).</div>')

    a, b = st.columns(2)
    with a:
        lt = T("SELECT * FROM lift_table")
        fig = go.Figure()
        fig.add_bar(x=lt["decile"], y=lt["churn_rate"] * 100, name="Churn rate % in decile", marker_color=PRIMARY)
        fig.add_scatter(x=lt["decile"], y=lt["cumulative_capture"] * 100, name="Cumulative churners captured %",
                        mode="lines+markers", line=dict(color=ORANGE, width=3))
        style_fig(fig, "Lift by risk decile", 400)
        fig.update_xaxes(title_text="Risk decile (1 = riskiest)", dtick=1)
        st.plotly_chart(fig)
    with b:
        imp = T("SELECT * FROM feature_importance ORDER BY mean_abs_shap DESC LIMIT 12").iloc[::-1]
        fig = px.bar(imp, x="mean_abs_shap", y="label", orientation="h", color_discrete_sequence=[PURPLE])
        st.plotly_chart(style_fig(fig, "Global drivers of churn (mean |SHAP|)", 400))

    with st.expander("Data notes & limitations"):
        st.markdown(
            "- **Leakage removed:** `Churn Score`, `Churn Reason`, `CLTV` and `Churn Label` are excluded from model inputs.\n"
            "- **Snapshot data:** the Telco file has no dates, so a time-based split is impossible; stratified split + "
            "5-fold out-of-fold scoring is used instead.\n"
            "- **Risk scores** shown in the app are out-of-fold (each customer scored by a model that never saw them).\n"
            "- **Opportunity impacts** are correlational estimates, not causal effects.")


EXAMPLES = ["Which contract has the highest churn?", "Which segment has the highest churn?",
            "Show the top 10 at-risk customers", "How much revenue is at risk?",
            "What should we do to reduce churn?", "What drives churn most?"]


def page_assistant():
    header("AI Assistant", "Ask in plain English - answers come from tested SQL and the model's insights")
    bot = get_assistant()
    mode = "local LLM (Ollama) connected" if bot.llm_ok else "rule-based mode (no LLM needed)"
    st.caption(f"Running in **{mode}**. Try a customer ID like `5178-LMXOP` too.")

    if "chat" not in st.session_state:
        st.session_state.chat = [{"role": "assistant", "content":
                                  "Hi! Ask me about churn, segments, revenue at risk, or a specific customer."}]
    prompt = None
    cols = st.columns(3)
    for i, ex in enumerate(EXAMPLES):
        if cols[i % 3].button(ex, key=f"ex{i}"):
            prompt = ex
    for m in st.session_state.chat:
        with st.chat_message(m["role"]):
            st.markdown(m["content"])
            if m.get("df") is not None:
                st.dataframe(m["df"], hide_index=True)
            if m.get("sql"):
                with st.expander("SQL used"):
                    st.code(m["sql"], language="sql")
    prompt = st.chat_input("Ask about churn...") or prompt
    if prompt:
        st.session_state.chat.append({"role": "user", "content": prompt})
        out = bot.answer(prompt)
        text = out["text"]
        if out.get("sources"):
            text += "\n\n*Sources: " + ", ".join(out["sources"]) + "*"
        st.session_state.chat.append({"role": "assistant", "content": text, "df": out.get("df"), "sql": out.get("sql")})
        st.rerun()


# ------------------------------------------------------------------ navigation
PAGES = [("overview", "Overview", page_overview),
         ("adoption", "Adoption & Retention", page_adoption),
         ("risk", "Churn Risk", page_risk),
         ("customer", "Customer Drill-down", page_customer),
         ("segments", "Segments", page_segments),
         ("opportunities", "Opportunities", page_opportunities),
         ("model", "Model Performance", page_model),
         ("assistant", "AI Assistant", page_assistant)]

if "page" not in st.session_state:
    st.session_state["page"] = "overview"
current = st.session_state["page"]

with st.sidebar:
    html('<div class="brand"><div class="brand-logo">P</div><div class="brand-name">ProductPulse</div></div>')
    for key, label, _ in PAGES:
        if st.button(label, key=f"nav_{key}", type="primary" if key == current else "secondary"):
            st.session_state["page"] = key
            st.rerun()

    alerts = Q("active_risk_list").head(4)
    n_high = int((Q("active_risk_list")["risk_score"] >= config.HIGH_RISK).sum())
    rows = ""
    for _, r in alerts.iterrows():
        letters = "".join(ch for ch in r.customer_id if ch.isalpha())[:2] or "C"
        dot = "red" if r.risk_score >= config.HIGH_RISK else "amber"
        rows += (f'<div class="alert-row"><div class="avatar">{letters}</div><div>'
                 f'<div class="alert-name">{r.customer_id}</div>'
                 f'<div class="alert-sub">{r.contract} · {r.risk_score:.0%} risk</div></div>'
                 f'<div class="dot {dot}"></div></div>')
    html(f'<div class="side-head"><span>At-risk alerts</span><span class="side-badge">{n_high}</span></div>{rows}')
    html(f'<div class="side-foot"><div class="t">XGBoost churn model</div><div class="d">ROC-AUC {OOF["roc_auc"]:.2f} · '
         f'PR-AUC {OOF["pr_auc"]:.2f}<br>Top-10% lift {OOF["lift_at_top10"]:.1f}x · leakage-free</div></div>')

for key, _, fn in PAGES:
    if key == current:
        fn()
