"""ProductPulse assistant - hybrid, API-free.

Routing order (most reliable first):
  1. Customer lookup   - a customer id like 7590-VHVEG  -> risk, reason, action
  2. Intent match      - TF-IDF similarity -> pre-written, tested SQL (never hallucinates)
  3. Knowledge (RAG)   - "why / what should we do" questions -> retrieve insight docs
                          (written by a local Ollama LLM if running, else shown directly)
  4. LLM text-to-SQL   - only if Ollama is running; validated by sql_guard, read-only DB
  5. Fallback          - "I don't have data for that" + suggestions
"""
import re
from typing import Optional

import pandas as pd
from ..db import get_conn, load_queries
from . import llm
from .textsim import Tfidf, cosine
from .intents import INTENTS, KNOWLEDGE_TRIGGERS
from .sql_guard import safe_sql

STRONG, WEAK, DOC_MIN = 0.60, 0.55, 0.06
ID_RE = re.compile(r"\b(\d{4}-[A-Za-z]{5})\b")

SCHEMA = """customers(customer_id, state, city, gender, senior_citizen 'Yes'/'No', partner, dependents, tenure_months,
  phone_service, multiple_lines, internet_service 'DSL'/'Fiber optic'/'No', online_security, online_backup,
  device_protection, tech_support, streaming_tv, streaming_movies 'Yes'/'No'/'No internet service',
  contract 'Month-to-month'/'One year'/'Two year', paperless_billing, payment_method, monthly_charges, total_charges,
  churned 1=churned 0=active, churn_reason, tenure_band, annual_revenue)
risk_scores(customer_id, risk_score 0..1, risk_band 'High'/'Medium'/'Low')
customer_explanations(customer_id, risk_score, plain_text_reason, protective_factor, recommended_action)
segments(customer_id, segment)
segment_profiles(segment, customers, churn_rate_pct, avg_tenure_months, avg_monthly_charges, active_mrr, mrr_at_risk)
opportunities(segment, lever, churn_gap_pp, est_annual_revenue_impact, insight)"""

SUGGESTIONS = ["Which contract has the highest churn?", "Which segment has the highest churn?",
               "Show the top 10 at-risk customers", "How much revenue is at risk?",
               "What should we do to reduce churn?", "Why do customers leave?"]


def _result(route, text, df=None, sql=None, **meta):
    return {"route": route, "text": text, "df": df, "sql": sql, **meta}


class Assistant:
    def __init__(self, use_llm: bool = True):
        self.queries = load_queries()
        self.llm_ok = bool(use_llm and llm.ollama_available())

        phrases, self.labels = [], []
        for name, examples in INTENTS.items():
            if name in self.queries:
                phrases += examples
                self.labels += [name] * len(examples)
        self.iv = Tfidf(analyzer="char_wb", ngram=(3, 5))
        self.iM = self.iv.fit_transform(phrases)

        con = get_conn()
        self.docs = pd.read_sql_query("SELECT * FROM insight_docs", con)
        con.close()
        self.dv = Tfidf(analyzer="word", ngram=(1, 2), stop=True)
        self.dM = self.dv.fit_transform((self.docs["title"] + ". " + self.docs["text"]).tolist())

    # ------------------------------------------------------------------ helpers
    def _sql(self, sql: str, params=None) -> pd.DataFrame:
        con = get_conn()
        try:
            return pd.read_sql_query(sql, con, params=params or {})
        finally:
            con.close()

    def match_intent(self, q: str):
        sims = cosine(self.iv.transform([q]), self.iM)
        i = int(sims.argmax())
        return self.labels[i], float(sims[i])

    def retrieve(self, q: str, k: int = 3):
        sims = cosine(self.dv.transform([q]), self.dM)
        idx = sims.argsort()[::-1][:k]
        return [(self.docs.iloc[i], float(sims[i])) for i in idx if sims[i] >= DOC_MIN]

    # ------------------------------------------------------------------ routes
    def customer(self, cid: str):
        df = self._sql(self.queries["customer_lookup"]["sql"], {"cid": cid.upper()})
        if df.empty:
            return _result("customer", f"I couldn't find customer **{cid.upper()}** in the data.")
        r = df.iloc[0]
        lines = [f"**Customer {r.customer_id}** - {r.status}, {r.contract}, {r.tenure_months} months tenure, "
                 f"${r.monthly_charges:.2f}/month.",
                 f"- **Churn risk:** {r.risk_score:.0%} ({r.risk_band}) | **Segment:** {r.segment}",
                 f"- **Why:** {r.plain_text_reason}"]
        if r.protective_factor:
            lines.append(f"- **Keeping them:** {r.protective_factor}")
        lines.append(f"- **Recommended action:** {r.recommended_action}")
        return _result("customer", "\n".join(lines), df=df, sql=self.queries["customer_lookup"]["sql"])

    def run_intent(self, name: str, q: str, score: float):
        params = {}
        if ":n" in self.queries[name]["sql"]:
            m = re.search(r"\b(\d{1,3})\b", q)
            params["n"] = min(max(int(m.group(1)), 1), 100) if m else 10
        df = self._sql(self.queries[name]["sql"], params)
        return _result("intent", self._summarize(name, df), df=df, sql=self.queries[name]["sql"],
                       intent=name, score=score)

    @staticmethod
    def _summarize(name: str, df: pd.DataFrame) -> str:
        if df.empty:
            return "The query returned no rows."
        if name == "kpi_overview":
            r = df.iloc[0]
            return (f"We have **{int(r.customers):,}** customers with an overall churn rate of **{r.churn_rate_pct}%**. "
                    f"Active MRR is **${r.active_mrr:,.0f}**; churned customers took **${r.lost_mrr:,.0f}** of MRR with them.")
        if name == "top_churn_reasons":
            return f"The most common reason is **{df.iloc[0, 0]}** ({df.iloc[0]['pct_of_churn']}% of churned customers)."
        if name == "mrr_at_risk_by_contract":
            return (f"About **${df['mrr_at_risk'].sum():,.0f}** of monthly revenue sits with "
                    f"**{int(df['high_risk_customers'].sum()):,}** active customers at >=50% churn risk.")
        if name in ("top_risk_customers", "high_value_at_risk"):
            return f"Here are the **{len(df)}** active customers with the highest churn risk."
        if name == "addon_adoption_vs_churn":
            return "Customers **with** protection/support add-ons churn far less than those without (see table)."
        if "churn_rate_pct" in df.columns and len(df) > 1:
            hi, lo = df.loc[df["churn_rate_pct"].idxmax()], df.loc[df["churn_rate_pct"].idxmin()]
            return (f"Highest churn: **{hi.iloc[0]}** at **{hi['churn_rate_pct']}%**; "
                    f"lowest: **{lo.iloc[0]}** at **{lo['churn_rate_pct']}%**.")
        return f"Here are the results ({len(df)} rows)."

    def knowledge(self, q: str, min_score: float = DOC_MIN):
        hits = [h for h in self.retrieve(q) if h[1] >= min_score]
        if not hits:
            return None
        sources = [d["title"] for d, _ in hits]
        if self.llm_ok:
            ctx = "\n".join(f"- {d['text']}" for d, _ in hits)
            ans = llm.generate(f"Context:\n{ctx}\n\nQuestion: {q}",
                               system="You are a product analytics assistant. Answer ONLY from the context, in under "
                                      "120 words. If the context lacks the answer, say you don't know.")
            if ans:
                return _result("knowledge", ans, sources=sources)
        body = "\n\n".join(f"**{d['title']}**\n{d['text']}" for d, _ in hits[:2])
        return _result("knowledge", "Here is what the analysis says:\n\n" + body, sources=sources)

    def text_to_sql(self, q: str):
        shots = "\n".join(f"-- {self.queries[n]['desc']}\n{self.queries[n]['sql']}"
                          for n in ("churn_by_contract", "mrr_at_risk_by_contract") if n in self.queries)
        system = ("You write one SQLite SELECT query. Use only these tables:\n" + SCHEMA +
                  "\nReturn ONLY the SQL, no explanation.\n\nExamples:\n" + shots)
        prompt, last_err = q, None
        for _ in range(2):  # one retry with the error message
            raw = llm.generate(prompt, system=system)
            if not raw:
                return None
            sql = re.sub(r"^```(?:sql)?|```$", "", raw.strip(), flags=re.I | re.M).strip()
            try:
                sql = safe_sql(sql)
                df = self._sql(sql)
                return _result("llm_sql", f"I wrote a query for that (LLM-generated, read-only). {len(df)} rows.",
                               df=df, sql=sql)
            except Exception as e:  # noqa: BLE001
                last_err = str(e)
                prompt = f"{q}\n\nYour previous SQL failed with: {last_err}\nFix it. Return only SQL."
        return None

    # ------------------------------------------------------------------ main entry
    def answer(self, question: str) -> dict:
        q = question.strip()
        if not q:
            return _result("fallback", "Ask me something about churn, segments, revenue at risk or a customer ID.")

        m = ID_RE.search(q)
        if m:
            return self.customer(m.group(1))

        intent, score = self.match_intent(q)
        if score >= STRONG:
            return self.run_intent(intent, q, score)

        if re.search(KNOWLEDGE_TRIGGERS, q, re.I):
            k = self.knowledge(q)
            if k:
                return k
        if score >= WEAK:
            return self.run_intent(intent, q, score)

        k = self.knowledge(q, min_score=0.15)
        if k:
            return k
        if self.llm_ok:
            r = self.text_to_sql(q)
            if r:
                return r
        return _result("fallback",
                       "I don't have data to answer that reliably. Try one of these:\n\n- " + "\n- ".join(SUGGESTIONS))
