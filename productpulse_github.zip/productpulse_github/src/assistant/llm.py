"""Optional local LLM through Ollama's HTTP API (no API key, no internet, no extra pip package).
If Ollama is not running, every function returns None and the assistant uses its rule-based layers."""
import json
import os
import urllib.request

HOST = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
MODEL = os.environ.get("OLLAMA_MODEL", "qwen2.5-coder:7b")


def ollama_available() -> bool:
    if os.environ.get("PP_DISABLE_LLM") == "1":
        return False
    try:
        urllib.request.urlopen(HOST + "/api/tags", timeout=1.0)
        return True
    except Exception:
        return False


def generate(prompt: str, system: str = "", timeout: int = 90):
    body = json.dumps({"model": MODEL, "prompt": prompt, "system": system, "stream": False,
                       "options": {"temperature": 0.1}}).encode()
    req = urllib.request.Request(HOST + "/api/generate", data=body, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read())["response"].strip()
    except Exception:
        return None
