"""Measure assistant routing accuracy:  python -m src.assistant.evaluate"""
import time

import pandas as pd

from .. import config
from .router import Assistant


def run(use_llm: bool = False, verbose: bool = True) -> dict:
    ev = pd.read_csv(config.ROOT / "tests" / "assistant_eval.csv").fillna("")
    bot, rows = Assistant(use_llm=use_llm), []
    for _, r in ev.iterrows():
        t = time.time()
        out = bot.answer(r.question)
        target = out.get("intent", "")
        rows.append({"question": r.question, "expected_route": r.expected_route, "got_route": out["route"],
                     "expected_target": r.expected_target, "got_target": target,
                     "ok": out["route"] == r.expected_route and (not r.expected_target or target == r.expected_target),
                     "ms": (time.time() - t) * 1000})
    res = pd.DataFrame(rows)
    stats = {"questions": len(res), "accuracy": float(res["ok"].mean()), "avg_latency_ms": float(res["ms"].mean())}
    if verbose:
        print(res[~res["ok"]].drop(columns=["ok"]).to_string(index=False) if (~res["ok"]).any() else "All correct.")
        print(f"\nAccuracy {stats['accuracy']:.0%} on {stats['questions']} questions | "
              f"avg latency {stats['avg_latency_ms']:.0f} ms")
    return stats


if __name__ == "__main__":
    run()
