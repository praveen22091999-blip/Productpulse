"""Intent catalogue: example phrasings -> named SQL query (sql/analytics_queries.sql)."""

INTENTS = {
    "kpi_overview": [
        "overall kpis", "how many customers do we have", "what is the overall churn rate",
        "total customers and churn", "business summary", "how much mrr do we have", "headline numbers"],
    "churn_by_contract": [
        "churn by contract type", "which contract has the highest churn", "month-to-month vs annual churn",
        "does a longer contract reduce churn", "contract churn comparison"],
    "churn_by_tenure_band": [
        "churn by tenure", "do new customers churn more", "how does tenure affect churn",
        "early life churn", "churn by customer age in months"],
    "churn_by_internet": [
        "churn by internet service", "fiber vs dsl churn", "do fiber customers churn more",
        "internet type churn rate"],
    "churn_by_payment": [
        "churn by payment method", "which payment method has the highest churn",
        "electronic check churn", "automatic payment and churn"],
    "churn_by_senior": [
        "churn for senior citizens", "do seniors churn more", "churn by age group"],
    "churn_by_monthly_charge": [
        "does price affect churn", "churn by monthly charges", "do expensive plans churn more",
        "churn by price band"],
    "churn_by_segment": [
        "which segment has the highest churn", "churn by customer segment", "segment churn ranking",
        "compare segments by churn", "how is churn different across segments",
        "how does churn differ between customer segments", "churn differences by segment"],
    "top_churn_reasons": [
        "why do customers leave", "top churn reasons", "most common reasons for churning",
        "what reasons do churned customers give", "why are customers leaving"],
    "mrr_at_risk_by_contract": [
        "how much revenue is at risk", "mrr at risk", "revenue at risk by contract",
        "how much monthly revenue could we lose", "predicted revenue loss"],
    "top_risk_customers": [
        "top at risk customers", "who is most likely to churn", "list high risk customers",
        "show riskiest customers", "customers likely to leave soon",
        "which customers should the retention team call first", "who should we contact first to save"],
    "high_value_at_risk": [
        "high value customers at risk", "big spenders likely to churn",
        "valuable customers about to leave", "high revenue customers with high churn risk"],
    "addon_adoption_vs_churn": [
        "do add-ons reduce churn", "tech support vs churn", "feature adoption and churn",
        "online security and churn", "which services reduce churn", "add on services retention"],
    "avg_revenue_by_contract": [
        "average revenue by contract", "arpu by contract type", "how much does each contract type pay"],
}

# questions that need explanation / recommendation rather than a table
KNOWLEDGE_TRIGGERS = (r"\b(why|recommend|should we|what should|how can we|how do we|how to|improve|reduce|drives?|driving|"
                      r"strategy|opportunit\w*|driver\w*|explain|insight\w*|build|retain|prevent|model|"
                      r"accuracy|auc|tell me about)\b")
