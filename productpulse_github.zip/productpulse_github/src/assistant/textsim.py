"""Tiny TF-IDF + cosine similarity in numpy (replaces scikit-learn's TfidfVectorizer).
Mirrors sklearn's recipe: smooth idf, sublinear tf, L2 normalisation."""
import re

import numpy as np

STOP = set("""a about above after again all also am an and any are as at be because been before being below between both but
by can could did do does doing down during each few for from further had has have having he her here hers him his how i if in
into is it its itself just me more most my myself no nor not now of off on once only or other our ours out over own same she
should so some such than that the their theirs them then there these they this those through to too under until up us very was
we were what when where which while who whom why will with would you your yours show top first tell give list""".split())
_WORD = re.compile(r"(?u)\b\w\w+\b")


class Tfidf:
    def __init__(self, analyzer="word", ngram=(1, 2), stop=False):
        self.analyzer, self.ngram, self.stop = analyzer, ngram, stop

    def _terms(self, text: str):
        text = text.lower()
        lo, hi = self.ngram
        out = []
        if self.analyzer == "word":
            toks = [t for t in _WORD.findall(text) if not (self.stop and t in STOP)]
            for n in range(lo, hi + 1):
                out += [" ".join(toks[i:i + n]) for i in range(len(toks) - n + 1)]
        else:  # char_wb
            for w in text.split():
                w = f" {w} "
                for n in range(lo, hi + 1):
                    out.append(w[:n])
                    i = 0
                    while i + n < len(w):
                        i += 1
                        out.append(w[i:i + n])
        return out

    def fit(self, texts):
        docs = [self._terms(t) for t in texts]
        vocab = sorted({t for d in docs for t in d})
        self.vocab = {t: i for i, t in enumerate(vocab)}
        df = np.zeros(len(vocab))
        for d in docs:
            for t in set(d):
                df[self.vocab[t]] += 1
        self.idf = np.log((1 + len(docs)) / (1 + df)) + 1
        return self

    def transform(self, texts):
        M = np.zeros((len(texts), len(self.vocab)))
        for r, t in enumerate(texts):
            for term in self._terms(t):
                j = self.vocab.get(term)
                if j is not None:
                    M[r, j] += 1
        nz = M > 0
        M[nz] = 1 + np.log(M[nz])
        M *= self.idf
        norm = np.linalg.norm(M, axis=1, keepdims=True)
        norm[norm == 0] = 1
        return M / norm

    def fit_transform(self, texts):
        return self.fit(texts).transform(texts)


def cosine(q_vec, matrix):
    """Rows are already L2-normalised, so cosine = dot product."""
    return (q_vec @ matrix.T)[0]
