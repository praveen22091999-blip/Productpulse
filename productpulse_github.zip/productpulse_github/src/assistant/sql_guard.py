"""Safety net for any SQL written by an LLM: SELECT-only, single statement, row limit."""
import re

FORBIDDEN = r"\b(insert|update|delete|drop|alter|create|attach|detach|pragma|replace|vacuum|reindex|truncate)\b"


def safe_sql(sql: str, max_rows: int = 200) -> str:
    s = sql.strip().rstrip(";").strip()
    if ";" in s:
        raise ValueError("Only a single statement is allowed")
    if not re.match(r"^(select|with)\b", s, re.I):
        raise ValueError("Only SELECT queries are allowed")
    if re.search(FORBIDDEN, s, re.I):
        raise ValueError("Forbidden keyword in query")
    if not re.search(r"\blimit\s+\d+", s, re.I):
        s += f" LIMIT {max_rows}"
    return s
