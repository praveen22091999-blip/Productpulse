"""STEP 3 - Train churn models: Logistic Regression baseline vs XGBoost.

Outputs: models/xgb_churn.json, models/metrics.json and DB tables
`features`, `risk_scores`, `lift_table`.
"""
import json

import numpy as np
import pandas as pd
import xgboost as xgb

from . import config
from .db import get_conn
from .features import build_features
from .mlkit import LogisticBaseline, average_precision, roc_auc, stratified_kfold, stratified_split


XGB_PARAMS = dict(objective="binary:logistic", eval_metric="logloss", eta=0.03, max_depth=4,
                  min_child_weight=3, subsample=0.8, colsample_bytree=0.8, reg_lambda=2.0,
                  seed=config.RANDOM_STATE)
XGB_ROUNDS = 400


class XGBModel:
    """Thin wrapper over xgboost's native API (no scikit-learn needed)."""

    def fit(self, X, y):
        self.booster = xgb.train(XGB_PARAMS, xgb.DMatrix(X, label=np.asarray(y)), num_boost_round=XGB_ROUNDS)
        return self

    def predict_proba(self, X):
        return self.booster.predict(xgb.DMatrix(X))


def top_fraction_stats(y, p, frac):
    """Recall, precision and lift when we act on the top `frac` riskiest customers."""
    y, p = np.asarray(y), np.asarray(p)
    k = max(1, int(round(len(y) * frac)))
    idx = np.argsort(-p)[:k]
    hits = y[idx].sum()
    return {"recall": float(hits / y.sum()), "precision": float(hits / k),
            "lift": float((hits / k) / y.mean())}


def evaluate(y, p):
    t = top_fraction_stats(y, p, config.TOP_PCT_CONTACTED)
    return {"roc_auc": roc_auc(y, p), "pr_auc": average_precision(y, p),
            "recall_at_top10": t["recall"], "precision_at_top10": t["precision"], "lift_at_top10": t["lift"]}


def business_value(y, p, annual_rev):
    """Back-test: contact top 10% risky customers, save SAVE_RATE of the real churners."""
    y, p, rev = np.asarray(y), np.asarray(p), np.asarray(annual_rev)
    k = max(1, int(round(len(y) * config.TOP_PCT_CONTACTED)))
    idx = np.argsort(-p)[:k]
    saved_rev = float((rev[idx] * y[idx]).sum() * config.SAVE_RATE)
    cost = float(k * config.CONTACT_COST)
    return {"customers_contacted": int(k), "revenue_saved": round(saved_rev, 0),
            "campaign_cost": round(cost, 0), "net_value": round(saved_rev - cost, 0)}


def lift_table(y, p, bins=10):
    df = pd.DataFrame({"y": np.asarray(y), "p": np.asarray(p)}).sort_values("p", ascending=False)
    df["decile"] = np.repeat(np.arange(1, bins + 1), int(np.ceil(len(df) / bins)))[: len(df)]
    g = df.groupby("decile").agg(customers=("y", "size"), churners=("y", "sum"), avg_risk=("p", "mean")).reset_index()
    g["churn_rate"] = g["churners"] / g["customers"]
    g["lift"] = g["churn_rate"] / df["y"].mean()
    g["cumulative_capture"] = g["churners"].cumsum() / g["churners"].sum()
    return g


def main():
    con = get_conn(read_only=False)
    df = pd.read_sql_query("SELECT * FROM customers", con)
    X, y = build_features(df), df["churned"]

    # NOTE: Telco is a one-time snapshot (no signup/churn dates), so a time-based split is
    # impossible. We use a stratified split + 5-fold out-of-fold scores instead.
    tr, te = stratified_split(y.values, config.TEST_SIZE, config.RANDOM_STATE)
    Xtr, Xte, ytr, yte = X.iloc[tr], X.iloc[te], y.iloc[tr], y.iloc[te]
    results = {}
    for name, maker in [("logistic_regression", LogisticBaseline), ("xgboost", XGBModel)]:
        m = maker().fit(Xtr, ytr)
        p = m.predict_proba(Xte)
        results[name] = evaluate(yte, p)
        if name == "xgboost":
            results["business_value_holdout"] = business_value(
                yte, p, df.loc[Xte.index, "annual_revenue"])
        print(f"[train] {name:20s} " + "  ".join(f"{k}={v:.3f}" for k, v in results[name].items()))

    # Out-of-fold risk score for EVERY customer (honest: never scored by a model that saw them)
    oof = np.zeros(len(df))
    for tr_i, te_i in stratified_kfold(y.values, 5, config.RANDOM_STATE):
        oof[te_i] = XGBModel().fit(X.iloc[tr_i], y.iloc[tr_i]).predict_proba(X.iloc[te_i])
    results["xgboost_cv_oof"] = evaluate(y, oof)
    print("[train] xgboost 5-fold OOF   " + "  ".join(f"{k}={v:.3f}" for k, v in results["xgboost_cv_oof"].items()))

    band = np.where(oof >= config.HIGH_RISK, "High", np.where(oof >= config.MEDIUM_RISK, "Medium", "Low"))
    pd.DataFrame({"customer_id": df["customer_id"], "risk_score": oof, "risk_band": band}) \
        .to_sql("risk_scores", con, index=False, if_exists="replace")
    lift_table(y, oof).to_sql("lift_table", con, index=False, if_exists="replace")
    feats = X.copy()
    feats.insert(0, "customer_id", df["customer_id"])
    feats.to_sql("features", con, index=False, if_exists="replace")

    XGBModel().fit(X, y).booster.save_model(str(config.MODEL_PATH))  # feature names are stored inside

    results["meta"] = {
        "rows": int(len(df)), "churn_rate": float(y.mean()), "n_features": int(X.shape[1]),
        "excluded_leaky_columns": ["churn_score", "churn_reason", "cltv", "churn_label"],
        "assumptions": {"top_pct": config.TOP_PCT_CONTACTED, "save_rate": config.SAVE_RATE,
                        "contact_cost": config.CONTACT_COST},
    }
    config.METRICS_PATH.write_text(json.dumps(results, indent=2))
    con.close()
    print(f"[train] saved model -> {config.MODEL_PATH.name}, metrics -> {config.METRICS_PATH.name}")


if __name__ == "__main__":
    main()
