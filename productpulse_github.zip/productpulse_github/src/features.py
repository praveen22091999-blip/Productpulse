"""STEP 2 - Feature engineering.

LEAKAGE NOTE: the raw file contains `churn_score`, `churn_reason`, `cltv`, `churn_label`.
These are produced AFTER / together with the churn outcome, so they are never used as
model inputs. Gender is also excluded on purpose (not a legitimate business driver).
"""
import re

import numpy as np
import pandas as pd

YES_NO = ["senior_citizen", "partner", "dependents", "phone_service", "paperless_billing"]
ADDONS = ["online_security", "online_backup", "device_protection", "tech_support",
          "streaming_tv", "streaming_movies"]
PROTECTION = ["online_security", "online_backup", "device_protection", "tech_support"]
CATEGORICAL = ["contract", "internet_service", "payment_method", "multiple_lines"]
NUMERIC = ["tenure_months", "monthly_charges", "total_charges"]
LEAKY_COLUMNS = ["churn_label", "churned", "churn_score", "churn_reason", "cltv"]


def _clean(name: str) -> str:
    return re.sub(r"[^0-9a-zA-Z_]+", "_", name).strip("_")


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    """Turn the cleaned `customers` table into a numeric model matrix."""
    X = pd.DataFrame(index=df.index)
    for c in NUMERIC:
        X[c] = df[c].astype(float)
    for c in YES_NO + ADDONS:
        X[c] = (df[c] == "Yes").astype(int)

    # engineered behavioural features
    X["num_addons"] = X[ADDONS].sum(axis=1)
    X["num_protection"] = X[PROTECTION].sum(axis=1)
    X["avg_paid_per_month"] = df["total_charges"] / df["tenure_months"].clip(lower=1)
    ratio = df["monthly_charges"] / X["avg_paid_per_month"].replace(0, np.nan)
    X["price_vs_avg_paid"] = ratio.fillna(1.0)
    X["is_new_customer"] = (df["tenure_months"] <= 6).astype(int)
    X["is_autopay"] = df["payment_method"].str.contains("automatic").astype(int)

    dummies = pd.get_dummies(df[CATEGORICAL], dtype=int)
    dummies.columns = [_clean(c) for c in dummies.columns]
    return pd.concat([X, dummies], axis=1)
