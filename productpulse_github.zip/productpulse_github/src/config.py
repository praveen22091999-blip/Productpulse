"""Central settings: paths + business assumptions used across the project."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_RAW = ROOT / "data" / "raw" / "Telco_customer_churn.xlsx"
DB_PATH = ROOT / "data" / "processed" / "productpulse.db"
MODEL_PATH = ROOT / "models" / "xgb_churn.json"
METRICS_PATH = ROOT / "models" / "metrics.json"
SQL_FILE = ROOT / "sql" / "analytics_queries.sql"

RANDOM_STATE = 42
TEST_SIZE = 0.20

# ---- Business assumptions (change these and re-run the pipeline) ----
TOP_PCT_CONTACTED = 0.10     # retention campaign targets the top 10% risky customers
SAVE_RATE = 0.30             # share of contacted would-be churners we manage to retain
CONTACT_COST = 20.0          # $ cost of one retention offer / call
ADOPTION_CONVERSION = 0.20   # share of non-adopters we can convince to adopt a feature/contract

# Risk bands used in dashboard + assistant
HIGH_RISK = 0.60
MEDIUM_RISK = 0.30
