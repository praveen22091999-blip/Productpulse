"""STEP 6 - Turn model/segment outputs into plain-language documents.
The AI assistant retrieves these (TF-IDF retrieval = lightweight RAG) to answer 'why' questions."""
import json

import pandas as pd

from . import config
from .db import get_conn, run_query


def main():
    con = get_conn(read_only=False)
    docs = []

    def add(kind, title, text):
        docs.append({"doc_id": len(docs) + 1, "kind": kind, "title": title, "text": text})

    k = run_query("kpi_overview", con=con).iloc[0]
    add("kpi", "Overall KPIs",
        f"The company has {int(k.customers):,} customers and an overall churn rate of {k.churn_rate_pct}%. "
        f"{int(k.churned_customers):,} customers have churned, losing ${k.lost_mrr:,.0f} in monthly recurring revenue. "
        f"Active MRR is ${k.active_mrr:,.0f}. Average tenure is {k.avg_tenure_months} months.")

    imp = pd.read_sql_query("SELECT * FROM feature_importance ORDER BY mean_abs_shap DESC LIMIT 8", con)
    add("drivers", "Top churn drivers (SHAP): what drives churn most",
        "The most important drivers of churn according to the XGBoost model and SHAP are: " +
        "; ".join(f"{i + 1}. {r.label} ({r.direction})" for i, r in imp.iterrows()) + ".")
    for i, r in imp.head(5).iterrows():
        add("driver", f"Driver: {r.label}",
            f"{r.label} is the number {i + 1} global driver of churn; {r.direction}. "
            f"Mean absolute SHAP impact is {r.mean_abs_shap:.2f} log-odds.")

    prof = pd.read_sql_query("SELECT * FROM segment_profiles ORDER BY churn_rate_pct DESC", con)
    opp = pd.read_sql_query("SELECT * FROM opportunities ORDER BY est_annual_revenue_impact DESC", con)
    for _, p in prof.iterrows():
        o = opp[opp["segment"] == p.segment].head(2)
        best = " Best retention levers: " + "; ".join(
            f"{r.lever} (churn gap {r.churn_gap_pp} pp, ~${r.est_annual_revenue_impact:,.0f}/yr)"
            for _, r in o.iterrows()) + "." if len(o) else ""
        add("segment", f"Segment: {p.segment}",
            f"Segment {p.segment}: {p.description} MRR at risk is ${p.mrr_at_risk:,.0f}.{best}")
    worst = prof.iloc[0]
    add("segment", "Highest churn segment",
        f"The segment with the highest churn is {worst.segment} at {worst.churn_rate_pct}% churn, "
        f"followed by {prof.iloc[1].segment} at {prof.iloc[1].churn_rate_pct}%.")

    for _, r in opp.head(20).iterrows():
        add("opportunity", f"Opportunity: {r.segment} - {r.lever}", r.insight)
    top5 = opp.head(5)
    add("recommendation", "What should we build or do to reduce churn",
        "Top retention and product opportunities to reduce churn, ranked by estimated annual revenue impact: " +
        "; ".join(f"{r['rank']}. {r.lever} for {r.segment} (~${r.est_annual_revenue_impact:,.0f}/yr)"
                  for _, r in top5.iterrows()) +
        ". Push customers toward longer contracts, bundle tech support and online security, and "
        "improve onboarding for new customers.")

    reasons = run_query("top_churn_reasons", con=con).head(5)
    add("reasons", "Stated churn reasons",
        "Customers who left most often gave these reasons: " +
        "; ".join(f"{r.churn_reason} ({r.pct_of_churn}%)" for _, r in reasons.iterrows()) + ".")

    m = json.loads(config.METRICS_PATH.read_text())
    x = m["xgboost_cv_oof"]
    add("model", "Model performance",
        f"The XGBoost churn model reaches ROC-AUC {x['roc_auc']:.2f} and PR-AUC {x['pr_auc']:.2f} (5-fold out-of-fold). "
        f"Targeting the top 10% riskiest customers captures {x['recall_at_top10']:.0%} of churners with "
        f"{x['lift_at_top10']:.1f}x lift over random targeting.")

    pd.DataFrame(docs).to_sql("insight_docs", con, index=False, if_exists="replace")
    con.commit()
    con.close()
    print(f"[insights] {len(docs)} insight documents saved")


if __name__ == "__main__":
    main()
