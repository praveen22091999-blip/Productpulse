"""STEP 1 - Load the raw Excel file, clean it, and create the SQLite database."""
import re

import pandas as pd

from . import config
from .db import get_conn


def snake(col: str) -> str:
    return re.sub(r"\W+", "_", col.strip()).lower()


def tenure_band(m: int) -> str:
    if m <= 6:
        return "0-6 mo"
    if m <= 12:
        return "7-12 mo"
    if m <= 24:
        return "13-24 mo"
    if m <= 48:
        return "25-48 mo"
    return "49-72 mo"


def load_clean() -> pd.DataFrame:
    df = pd.read_excel(config.DATA_RAW)
    df.columns = [snake(c) for c in df.columns]
    df = df.rename(columns={"customerid": "customer_id", "churn_value": "churned"})

    # Total Charges has blanks for brand-new customers (tenure = 0) -> treat as 0
    df["total_charges"] = pd.to_numeric(df["total_charges"], errors="coerce").fillna(0.0)

    # Drop constant / redundant columns
    df = df.drop(columns=["count", "country", "lat_long", "churn_label"], errors="ignore")

    df["tenure_band"] = df["tenure_months"].apply(tenure_band)
    df["annual_revenue"] = (df["monthly_charges"] * 12).round(2)
    return df


def main():
    config.DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    if config.DB_PATH.exists():
        config.DB_PATH.unlink()
    df = load_clean()
    con = get_conn(read_only=False)
    df.to_sql("customers", con, index=False)
    con.execute("CREATE UNIQUE INDEX idx_customers_id ON customers(customer_id)")
    con.execute("CREATE INDEX idx_customers_contract ON customers(contract)")
    con.commit()
    con.close()
    print(f"[build_db] customers table: {len(df):,} rows, churn rate {df['churned'].mean():.1%}")


if __name__ == "__main__":
    main()
