"""SQLite helpers + loader for the named queries in sql/analytics_queries.sql."""
import re
import sqlite3
from typing import Optional

import pandas as pd

from . import config


def get_conn(read_only: bool = True) -> sqlite3.Connection:
    """Read-only by default, so the dashboard / assistant can never modify data."""
    if read_only:
        uri = config.DB_PATH.resolve().as_uri() + "?mode=ro"
        return sqlite3.connect(uri, uri=True, check_same_thread=False)
    return sqlite3.connect(config.DB_PATH)


_NAME = re.compile(r"^--\s*name:\s*(\w+)\s*$")
_DESC = re.compile(r"^--\s*desc:\s*(.*)$")


def load_queries(path=None) -> dict:
    """Parse the .sql file into {name: {'sql':..., 'desc':...}}."""
    path = path or config.SQL_FILE
    queries, state = {}, {"name": None, "desc": "", "buf": []}

    def flush():
        if state["name"] and state["buf"]:
            queries[state["name"]] = {
                "sql": "\n".join(state["buf"]).strip().rstrip(";"),
                "desc": state["desc"],
            }

    for line in path.read_text(encoding="utf-8").splitlines():
        s = line.strip()
        m = _NAME.match(s)
        if m:
            flush()
            state.update(name=m.group(1), desc="", buf=[])
            continue
        d = _DESC.match(s)
        if d and state["name"]:
            state["desc"] = d.group(1)
            continue
        if state["name"] and not s.startswith("--"):
            state["buf"].append(line)
    flush()
    return queries


def run_query(name: str, params: Optional[dict] = None, con=None) -> pd.DataFrame:
    queries = load_queries()
    if name not in queries:
        raise KeyError(f"Unknown query: {name}")
    own = con is None
    con = con or get_conn()
    try:
        return pd.read_sql_query(queries[name]["sql"], con, params=params or {})
    finally:
        if own:
            con.close()
