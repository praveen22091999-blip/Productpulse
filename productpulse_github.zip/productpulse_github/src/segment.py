"""STEP 5 - Customer segmentation (K-Means) + product opportunity analysis."""
import numpy as np
import pandas as pd
from . import config
from .db import get_conn
from .features import build_features
from .mlkit import kmeans, silhouette, standardize

CONTRACT_MONTHS = {"Month-to-month": 0, "One year": 12, "Two year": 24}
SEG_FEATURES = ["tenure_months", "monthly_charges", "num_addons", "contract_months", "is_fiber", "num_streaming"]
K_RANGE = range(4, 7)  # 4-6 clusters keeps segments interpretable for business users


def name_cluster(p: dict, o: dict) -> str:
    """Rule-based business names from cluster averages (p) vs overall averages (o)."""
    committed = p["contract_months"] >= 14
    fiber = p["is_fiber"] > 0.6
    if p["monthly_charges"] < 45 and p["is_fiber"] < 0.3:
        return "Basic Phone-Only Loyalists" if committed else "Budget Month-to-Month"
    if committed and p["tenure_months"] >= o["tenure_months"]:
        return "Premium Fiber Loyalists" if fiber else "Committed DSL Loyalists"
    if fiber and p["contract_months"] < 8:
        return "Fiber High-Spenders" if p["monthly_charges"] >= 1.3 * o["monthly_charges"] else "Newer Fiber Customers"
    return "Mid-Tenure Flexible"


def main():
    con = get_conn(read_only=False)
    df = pd.read_sql_query("SELECT * FROM customers", con)
    X = build_features(df)
    risk = pd.read_sql_query("SELECT customer_id, risk_score FROM risk_scores", con)

    seg = pd.DataFrame({
        "tenure_months": df["tenure_months"], "monthly_charges": df["monthly_charges"],
        "num_addons": X["num_addons"], "contract_months": df["contract"].map(CONTRACT_MONTHS),
        "is_fiber": (df["internet_service"] == "Fiber optic").astype(int),
        "num_streaming": X["streaming_tv"] + X["streaming_movies"],
    })[SEG_FEATURES]
    Z = standardize(seg)

    scores = []
    for k in K_RANGE:
        lab, inertia = kmeans(Z, k, n_init=10, seed=config.RANDOM_STATE)
        scores.append({"k": k, "silhouette": silhouette(Z, lab), "inertia": inertia})
    best_k = max(scores, key=lambda s: s["silhouette"])["k"]
    pd.DataFrame(scores).to_sql("segment_k_scores", con, index=False, if_exists="replace")
    labels, _ = kmeans(Z, best_k, n_init=10, seed=config.RANDOM_STATE)

    overall = seg.mean().to_dict()
    names, used = {}, set()
    for c in range(best_k):
        nm = name_cluster(seg[labels == c].mean().to_dict(), overall)
        names[c] = nm if nm not in used else f"{nm} {c + 1}"
        used.add(nm)
    df["segment"] = [names[c] for c in labels]
    df = df.merge(risk, on="customer_id")

    df[["customer_id", "segment"]].to_sql("segments", con, index=False, if_exists="replace")

    # ---------------- segment profiles ----------------
    prof = []
    for s, g in df.groupby("segment"):
        active = g[g["churned"] == 0]
        gi = g.index
        p = {
            "segment": s, "customers": len(g), "share_pct": round(100 * len(g) / len(df), 1),
            "churn_rate_pct": round(100 * g["churned"].mean(), 1),
            "avg_tenure_months": round(g["tenure_months"].mean(), 1),
            "avg_monthly_charges": round(g["monthly_charges"].mean(), 2),
            "avg_addons": round(X.loc[gi, "num_addons"].mean(), 2),
            "pct_month_to_month": round(100 * (g["contract"] == "Month-to-month").mean(), 1),
            "pct_fiber": round(100 * (g["internet_service"] == "Fiber optic").mean(), 1),
            "active_mrr": round(active["monthly_charges"].sum(), 0),
            "mrr_at_risk": round(active.loc[active["risk_score"] >= 0.5, "monthly_charges"].sum(), 0),
        }
        p["description"] = (f"{p['customers']:,} customers ({p['share_pct']}%); churn {p['churn_rate_pct']}%; "
                            f"avg tenure {p['avg_tenure_months']:.0f} mo; ${p['avg_monthly_charges']:.0f}/mo; "
                            f"{p['avg_addons']:.1f} add-ons; {p['pct_month_to_month']:.0f}% month-to-month; "
                            f"{p['pct_fiber']:.0f}% fiber.")
        prof.append(p)
    prof = pd.DataFrame(prof).sort_values("churn_rate_pct", ascending=False)
    prof.to_sql("segment_profiles", con, index=False, if_exists="replace")

    # ---------------- opportunities ----------------
    Xf = X.copy()
    levers = {  # lever name -> (eligible mask, adopter mask)
        "Tech Support": (df["internet_service"] != "No", df["tech_support"] == "Yes"),
        "Online Security": (df["internet_service"] != "No", df["online_security"] == "Yes"),
        "Online Backup": (df["internet_service"] != "No", df["online_backup"] == "Yes"),
        "Device Protection": (df["internet_service"] != "No", df["device_protection"] == "Yes"),
        "Longer contract (1-2 yr)": (pd.Series(True, index=df.index), df["contract"] != "Month-to-month"),
        "Automatic payment": (pd.Series(True, index=df.index), Xf["is_autopay"] == 1),
    }
    opp = []
    for s, g in df.groupby("segment"):
        for lever, (elig, adopt) in levers.items():
            ge = g[elig.loc[g.index]]
            ad, non = ge[adopt.loc[ge.index]], ge[~adopt.loc[ge.index]]
            if len(ad) < 30 or len(non) < 30:
                continue  # too few customers for a trustworthy comparison
            gap = max(0.0, non["churned"].mean() - ad["churned"].mean())
            target = non[non["churned"] == 0]  # only active customers can still be acted on
            saved = len(target) * config.ADOPTION_CONVERSION * gap
            rev = saved * (target["annual_revenue"].mean() if len(target) else 0)
            opp.append({
                "segment": s, "lever": lever,
                "adoption_rate_pct": round(100 * len(ad) / len(ge), 1),
                "churn_with_pct": round(100 * ad["churned"].mean(), 1),
                "churn_without_pct": round(100 * non["churned"].mean(), 1),
                "churn_gap_pp": round(100 * gap, 1),
                "addressable_active_customers": int(len(target)),
                "est_customers_retained": round(saved, 1),
                "est_annual_revenue_impact": round(rev, 0),
            })
    opp = pd.DataFrame(opp).sort_values("est_annual_revenue_impact", ascending=False).reset_index(drop=True)
    opp["rank"] = opp.index + 1
    opp["insight"] = opp.apply(lambda r: (
        f"In '{r.segment}', customers without {r.lever} churn {r.churn_without_pct}% vs {r.churn_with_pct}% "
        f"with it (gap {r.churn_gap_pp} pp). Converting {int(config.ADOPTION_CONVERSION * 100)}% of "
        f"{r.addressable_active_customers} active non-adopters could retain ~{r.est_customers_retained:.0f} "
        f"customers (~${r.est_annual_revenue_impact:,.0f}/year). Correlation, not proven causation - test with an A/B pilot."
    ), axis=1)
    opp.to_sql("opportunities", con, index=False, if_exists="replace")
    con.commit()
    con.close()
    print(f"[segment] k={best_k} (silhouette {max(s['silhouette'] for s in scores):.3f})")
    print(prof[["segment", "customers", "churn_rate_pct", "avg_tenure_months", "avg_monthly_charges",
                "avg_addons", "pct_month_to_month", "pct_fiber"]].to_string(index=False))
    print(f"[segment] opportunities: {len(opp)} rows; top: {opp.loc[0, 'segment']} / {opp.loc[0, 'lever']}")


if __name__ == "__main__":
    main()
