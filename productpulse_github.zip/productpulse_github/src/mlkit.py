"""Small numpy/pandas replacements for the few scikit-learn tools we used.
Why: some locked-down Windows PCs (Application Control / Smart App Control) block scikit-learn's
compiled files. numpy + pandas + xgboost load fine, so the project depends only on those."""
import numpy as np
import pandas as pd


# ---------------------------------------------------------------- metrics
def roc_auc(y, p) -> float:
    y, p = np.asarray(y), np.asarray(p)
    ranks = pd.Series(p).rank().values  # average ranks handle ties
    n1, n0 = int(y.sum()), int(len(y) - y.sum())
    return float((ranks[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


def average_precision(y, p) -> float:
    y, p = np.asarray(y), np.asarray(p)
    ys = y[np.argsort(-p, kind="mergesort")]
    tp = np.cumsum(ys)
    precision = tp / np.arange(1, len(ys) + 1)
    return float((precision * ys).sum() / ys.sum())


# ---------------------------------------------------------------- splitting
def stratified_split(y, test_size: float, seed: int):
    y, rng = np.asarray(y), np.random.RandomState(seed)
    test = []
    for c in np.unique(y):
        idx = rng.permutation(np.where(y == c)[0])
        test.extend(idx[: int(round(len(idx) * test_size))])
    test = np.sort(np.array(test))
    return np.setdiff1d(np.arange(len(y)), test), test


def stratified_kfold(y, n_splits: int, seed: int):
    y, rng = np.asarray(y), np.random.RandomState(seed)
    folds = [[] for _ in range(n_splits)]
    for c in np.unique(y):
        idx = rng.permutation(np.where(y == c)[0])
        for i, chunk in enumerate(np.array_split(idx, n_splits)):
            folds[i].extend(chunk)
    for i in range(n_splits):
        te = np.sort(np.array(folds[i]))
        yield np.setdiff1d(np.arange(len(y)), te), te


# ---------------------------------------------------------------- logistic regression (baseline)
class LogisticBaseline:
    """Standardised, L2-regularised, class-balanced logistic regression solved with Newton's method."""

    def __init__(self, l2: float = 1.0, iters: int = 50):
        self.l2, self.iters = l2, iters

    def fit(self, X, y):
        X, y = np.asarray(X, dtype=float), np.asarray(y, dtype=float)
        self.mu, self.sd = X.mean(0), X.std(0)
        self.sd[self.sd == 0] = 1.0
        Z = np.hstack([np.ones((len(X), 1)), (X - self.mu) / self.sd])
        w_cls = {1: len(y) / (2 * y.sum()), 0: len(y) / (2 * (len(y) - y.sum()))}
        sw = np.where(y == 1, w_cls[1], w_cls[0])
        reg = self.l2 * np.eye(Z.shape[1])
        reg[0, 0] = 0.0  # do not penalise the intercept
        beta = np.zeros(Z.shape[1])
        for _ in range(self.iters):
            p = 1 / (1 + np.exp(-np.clip(Z @ beta, -30, 30)))
            grad = Z.T @ (sw * (p - y)) + reg @ beta
            hess = (Z * (sw * p * (1 - p))[:, None]).T @ Z + reg + 1e-8 * np.eye(Z.shape[1])
            step = np.linalg.solve(hess, grad)
            beta -= step
            if np.abs(step).max() < 1e-6:
                break
        self.beta = beta
        return self

    def predict_proba(self, X):
        Z = np.hstack([np.ones((len(X), 1)), (np.asarray(X, dtype=float) - self.mu) / self.sd])
        return 1 / (1 + np.exp(-np.clip(Z @ self.beta, -30, 30)))


# ---------------------------------------------------------------- clustering
def standardize(df: pd.DataFrame) -> np.ndarray:
    a = df.values.astype(float)
    sd = a.std(0)
    sd[sd == 0] = 1.0
    return (a - a.mean(0)) / sd


def _kmeans_once(Z, k, rng, iters=100):
    n = len(Z)
    centers = [Z[rng.randint(n)]]
    for _ in range(1, k):  # k-means++ seeding
        d2 = np.min(((Z[:, None, :] - np.array(centers)[None]) ** 2).sum(2), axis=1)
        centers.append(Z[rng.choice(n, p=d2 / d2.sum())])
    centers = np.array(centers)
    for _ in range(iters):
        d = ((Z[:, None, :] - centers[None]) ** 2).sum(2)
        labels = d.argmin(1)
        new = np.array([Z[labels == c].mean(0) if (labels == c).any() else centers[c] for c in range(k)])
        if np.allclose(new, centers, atol=1e-6):
            break
        centers = new
    d = ((Z[:, None, :] - centers[None]) ** 2).sum(2)
    labels = d.argmin(1)
    return labels, float(d[np.arange(n), labels].sum())


def kmeans(Z, k: int, n_init: int = 10, seed: int = 42):
    rng = np.random.RandomState(seed)
    best = min((_kmeans_once(Z, k, rng) for _ in range(n_init)), key=lambda r: r[1])
    return best  # (labels, inertia)


def silhouette(Z, labels, sample: int = 2500, seed: int = 42) -> float:
    rng = np.random.RandomState(seed)
    idx = rng.choice(len(Z), min(sample, len(Z)), replace=False)
    Zs, ls = Z[idx], np.asarray(labels)[idx]
    D = np.sqrt(((Zs[:, None, :] - Zs[None]) ** 2).sum(2))
    ks = np.unique(ls)
    sums = np.stack([D[:, ls == c].sum(1) for c in ks], axis=1)
    counts = np.array([(ls == c).sum() for c in ks])
    own = np.searchsorted(ks, ls)
    a = sums[np.arange(len(ls)), own] / np.maximum(counts[own] - 1, 1)
    other = sums / counts
    other[np.arange(len(ls)), own] = np.inf
    b = other.min(1)
    return float(np.mean((b - a) / np.maximum(a, b)))
