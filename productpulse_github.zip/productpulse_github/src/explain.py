"""STEP 4 - SHAP explainability.

XGBoost's built-in `pred_contribs=True` returns exact TreeSHAP values (the same numbers
`shap.TreeExplainer` gives), so no extra dependency is needed. Values are in log-odds:
positive = pushes churn risk UP, negative = pushes it DOWN.
"""
import numpy as np
import pandas as pd
import xgboost as xgb

from . import config
from .db import get_conn
from .features import CATEGORICAL

BINARY_TEXT = {  # feature: (text when 1, text when 0)
    "senior_citizen": ("is a senior citizen", "is not a senior citizen"),
    "partner": ("has a partner", "has no partner"),
    "dependents": ("has dependents", "has no dependents"),
    "phone_service": ("has phone service", "has no phone service"),
    "paperless_billing": ("uses paperless billing", "does not use paperless billing"),
    "online_security": ("has online security", "no online security"),
    "online_backup": ("has online backup", "no online backup"),
    "device_protection": ("has device protection", "no device protection"),
    "tech_support": ("has tech support", "no tech support"),
    "streaming_tv": ("streams TV", "does not stream TV"),
    "streaming_movies": ("streams movies", "does not stream movies"),
    "is_new_customer": ("is a new customer (<= 6 months)", "is not a new customer"),
    "is_autopay": ("pays automatically", "does not use automatic payment"),
}

ACTIONS = {  # first matching top driver decides the recommended action
    "contract_Month_to_month": "Offer a discounted 1-year contract with a loyalty perk.",
    "tenure_months": "Run an onboarding / check-in call and share a welcome bundle.",
    "is_new_customer": "Run an onboarding / check-in call and share a welcome bundle.",
    "tech_support": "Offer a free 3-month tech-support trial.",
    "online_security": "Bundle online security free for 3 months.",
    "online_backup": "Offer online backup free for 3 months.",
    "device_protection": "Offer discounted device protection.",
    "monthly_charges": "Review the plan; offer a right-sized or loyalty-discounted bundle.",
    "price_vs_avg_paid": "Explain the bill change and offer a price-lock for 12 months.",
    "internet_service_Fiber_optic": "Check fiber service quality and offer a speed/price review.",
    "payment_method_Electronic_check": "Nudge to automatic payment with a small bill credit.",
    "is_autopay": "Nudge to automatic payment with a small bill credit.",
    "paperless_billing": "Check billing clarity; offer a billing walkthrough.",
    "num_addons": "Recommend a value add-on bundle matching their usage.",
    "num_protection": "Recommend a security + support bundle.",
    "total_charges": "Add the customer to a loyalty / early-tenure retention journey.",
}
DEFAULT_ACTION = "Assign to the retention team for a personal check-in."


def pretty(col: str) -> str:
    for cat in CATEGORICAL:
        if col.startswith(cat + "_"):
            return f"{cat.replace('_', ' ').title()}: {col[len(cat) + 1:].replace('_', ' ')}"
    return col.replace("_", " ").capitalize()


def describe(col: str, value: float) -> str:
    """Human-readable phrase for one feature value."""
    for cat in CATEGORICAL:
        if col.startswith(cat + "_"):
            val = col[len(cat) + 1:].replace("_", " ")
            label = cat.replace("_", " ")
            return f"{label}: {val}" if value >= 0.5 else f"{label} is not {val}"
    if col in BINARY_TEXT:
        return BINARY_TEXT[col][0 if value >= 0.5 else 1]
    v = float(value)
    if col == "tenure_months":
        level = "short" if v <= 12 else "long" if v >= 36 else "mid-length"
        return f"{level} tenure ({int(v)} mo)"
    if col == "monthly_charges":
        level = "high" if v >= 80 else "low" if v <= 40 else "moderate"
        return f"{level} monthly bill (${v:.0f})"
    if col == "total_charges":
        level = "low" if v < 1500 else "high" if v >= 4000 else "moderate"
        return f"{level} lifetime spend (${v:,.0f})"
    if col == "avg_paid_per_month":
        level = "high" if v >= 80 else "low" if v <= 40 else "moderate"
        return f"{level} average monthly spend (${v:.0f})"
    if col == "price_vs_avg_paid":
        return f"current bill is {v:.2f}x their historical average"
    if col in ("num_addons", "num_protection"):
        kind = "protection" if col == "num_protection" else "add-on"
        return f"{int(v)} {kind} service{'s' if int(v) != 1 else ''}"
    return f"{col.replace('_', ' ')} = {v:.2f}"


def main():
    booster = xgb.Booster()
    booster.load_model(str(config.MODEL_PATH))
    cols = list(booster.feature_names)
    con = get_conn(read_only=False)
    feats = pd.read_sql_query("SELECT * FROM features", con)
    ids = feats["customer_id"]
    X = feats[cols]

    contribs = booster.predict(xgb.DMatrix(X), pred_contribs=True)
    sv = pd.DataFrame(np.asarray(contribs)[:, :-1], columns=cols)

    # ---- global importance + direction (does a higher value raise or lower risk?) ----
    imp = pd.DataFrame({"feature": cols, "mean_abs_shap": sv.abs().mean().values})
    imp["direction"] = [
        "higher values raise churn risk" if np.corrcoef(X[c], sv[c])[0, 1] > 0
        else "higher values lower churn risk" if np.corrcoef(X[c], sv[c])[0, 1] < 0 else "mixed"
        if X[c].std() > 0 else "no variation"
        for c in cols
    ]
    imp["label"] = imp["feature"].map(pretty)
    imp.sort_values("mean_abs_shap", ascending=False).to_sql(
        "feature_importance", con, index=False, if_exists="replace")

    # ---- per-customer explanations ----
    risk = pd.read_sql_query("SELECT * FROM risk_scores", con).set_index("customer_id").loc[ids]
    rows = []
    sv_arr, x_arr = sv.values, X.values
    for i in range(len(ids)):
        order = np.argsort(-sv_arr[i])
        up = [j for j in order[:3] if sv_arr[i, j] > 0.05]
        down = np.argsort(sv_arr[i])[0]
        drivers = [cols[j] for j in up]
        reason = ("Main risk drivers: " + "; ".join(describe(cols[j], x_arr[i, j]) for j in up) + ".") \
            if up else "No strong risk drivers - profile looks stable."
        protective = describe(cols[down], x_arr[i, down]) if sv_arr[i, down] < -0.05 else ""
        action = next((ACTIONS[d] for d in drivers if d in ACTIONS), DEFAULT_ACTION)
        rows.append({
            "customer_id": ids.iloc[i],
            "risk_score": float(risk["risk_score"].iloc[i]),
            "risk_band": risk["risk_band"].iloc[i],
            "driver_1": drivers[0] if len(drivers) > 0 else "",
            "driver_2": drivers[1] if len(drivers) > 1 else "",
            "driver_3": drivers[2] if len(drivers) > 2 else "",
            "plain_text_reason": reason,
            "protective_factor": protective,
            "recommended_action": action,
        })
    pd.DataFrame(rows).to_sql("customer_explanations", con, index=False, if_exists="replace")

    sv.insert(0, "customer_id", ids.values)
    sv.to_sql("shap_values", con, index=False, if_exists="replace")
    con.execute("CREATE INDEX IF NOT EXISTS idx_expl_id ON customer_explanations(customer_id)")
    con.commit()
    con.close()
    top = imp.sort_values("mean_abs_shap", ascending=False).head(5)
    print("[explain] top global drivers:", ", ".join(top["label"]))
    print(f"[explain] customer_explanations: {len(rows):,} rows")


if __name__ == "__main__":
    main()
