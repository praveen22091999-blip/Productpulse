# ProductPulse: AI-Driven Product Analytics & Customer Insights

An end-to-end analytics platform that answers four product questions on telecom customer data:
**Who will churn? Why? Which customer segments exist? Where are the product opportunities?**

**Stack:** SQL (SQLite) · Python (numpy / pandas) · XGBoost · SHAP (TreeSHAP) · K-Means · Streamlit + Plotly ·
API-free AI assistant (intent routing + retrieval + optional local LLM via Ollama)

![Executive overview](docs/screenshots/01_overview.png)

## Key results

Data: public IBM Telco Customer Churn sample, 7,043 customers, 26.5% churn.

| Metric | Logistic regression | XGBoost | XGBoost (5-fold out-of-fold) |
|---|---|---|---|
| ROC-AUC | 0.867 | 0.870 | **0.861** |
| PR-AUC (baseline 0.27) | 0.689 | 0.699 | **0.680** |
| Recall in top 10% riskiest | 30.2% | 29.7% | **29%** |
| Lift in top 10% | 3.0x | 3.0x | **2.9x** |

- **Contract matters most:** month-to-month customers churn at 42.7% versus 2.8% on two-year contracts.
- **Early life is the danger zone:** customers in their first 6 months churn at about 53%.
- **6 behavioural segments:** from "Newer Fiber Customers" (54.8% churn) to "Basic Phone-Only Loyalists" (1.6%).
- **Revenue at risk:** about $40K of monthly revenue sits with 522 active customers at 50% or higher predicted risk.
- **Campaign back-test (20% hold-out):** contacting the top 10% riskiest customers (141 customers) would save roughly
  $32K of annual revenue for $2.8K of campaign cost, net about $29K. This assumes a 30% save rate and $20 per contact;
  both are adjustable in `src/config.py` and in the dashboard simulator.
- **Assistant:** 100% routing accuracy on the 33-question test set in `tests/assistant_eval.csv` (this set was used to
  tune thresholds, so treat it as optimistic), about 11 ms average latency in rule-based mode.

A plain logistic regression is almost as good as XGBoost on this data. The value of the project is in explanations,
segmentation and actions, not in squeezing out another point of AUC.

## Dashboard

| | |
|---|---|
| ![Adoption](docs/screenshots/02_adoption_retention.png) | ![Drill-down](docs/screenshots/03_customer_drilldown.png) |
| ![Segments](docs/screenshots/04_segments.png) | ![Model](docs/screenshots/05_model_performance.png) |

![AI assistant](docs/screenshots/06_ai_assistant.png)

Pages: Overview, Adoption & Retention, Churn Risk (with a retention campaign simulator), Customer Drill-down (SHAP),
Segments, Opportunities, Model Performance, AI Assistant.

## Architecture

```
Telco_customer_churn.xlsx
   -> SQL database (SQLite) ----------------------------+
   -> Leakage-free features -> XGBoost -> risk scores   |
                            -> SHAP    -> reasons+actions +--> Streamlit dashboard
                            -> K-Means -> segments       |    + AI assistant
                            -> opportunities, insights --+
```

## Quick start

```bash
git clone https://github.com/<your-username>/productpulse.git
cd productpulse
python -m venv venv
venv\Scripts\activate            # Windows        |  source venv/bin/activate   # macOS / Linux
pip install -r requirements.txt

python run_pipeline.py           # about 1 minute: database, models, SHAP, segments, insights
streamlit run app/dashboard.py   # opens the dashboard in your browser
```

Optional: `python -m src.assistant.evaluate` (assistant accuracy) and `pytest -q` (tests).

Notes:
- macOS XGBoost error mentioning `libomp`: run `brew install libomp`.
- Windows "Application Control policy blocked this file": this project deliberately avoids scikit-learn.
  `src/mlkit.py` and `src/assistant/textsim.py` re-implement the few tools needed using only numpy and pandas.
- Generated files (`data/processed/productpulse.db`, `models/`) are created by `run_pipeline.py` and are git-ignored.

## Project structure

```
productpulse/
├── run_pipeline.py            # runs all steps in order
├── sql/analytics_queries.sql  # 19 named, documented queries (CTEs, window functions, joins)
├── src/
│   ├── build_db.py            # clean raw Excel -> SQLite
│   ├── features.py            # feature engineering + leakage handling
│   ├── train.py               # logistic regression vs XGBoost, lift, business value
│   ├── explain.py             # SHAP -> plain-English reasons and recommended actions
│   ├── segment.py             # K-Means segments + opportunity sizing
│   ├── insights.py            # insight documents for the assistant
│   ├── mlkit.py               # numpy implementations of metrics, splits, logistic regression, K-Means
│   └── assistant/             # router, intents, TF-IDF, SQL guard, optional Ollama client, evaluation
├── app/                       # Streamlit dashboard and theme
├── tests/                     # assistant evaluation set and pytest tests
└── docs/screenshots/
```

## The AI assistant (no API key needed)

Routing order, from most to least reliable:
1. **Customer lookup:** a customer ID returns risk, reasons and a recommended action.
2. **Intent match:** TF-IDF similarity maps the question to a pre-written, tested SQL query.
3. **Knowledge retrieval:** "why" and "what should we do" questions retrieve insight documents.
4. **LLM text-to-SQL:** only if [Ollama](https://ollama.com) is running locally (`ollama pull qwen2.5-coder:7b`).
   Every generated query passes `sql_guard.py` (SELECT-only, single statement, row limit) on a read-only connection.
5. **Fallback:** "I don't have data for that" plus suggested questions.

Without Ollama everything still works in rule-based mode.

## Limitations

- **Data leakage handled:** `Churn Score`, `Churn Reason`, `CLTV` and `Churn Label` exist in the raw file but are not
  used as model inputs. Gender is also excluded.
- **Snapshot data:** the dataset has no dates, so there is no time-based split and no true cohort analysis. A stratified
  split plus 5-fold out-of-fold scoring is used instead.
- **Opportunity sizing is correlational:** customers with tech support churn less, but that does not prove tech support
  causes retention. Treat the estimates as hypotheses for A/B tests.
- **Business assumptions** (30% save rate, $20 contact cost, 20% adoption conversion) are illustrative.
- **Assistant evaluation** is small and was used to tune thresholds, so real-world accuracy will be lower on unseen phrasing.

## Data

IBM Telco Customer Churn sample dataset (public). The Excel file is included in `data/raw/` for reproducibility.

## License

MIT. See [LICENSE](LICENSE).

## Author

[YOUR NAME] · [LinkedIn](https://www.linkedin.com/in/your-profile)
