"""Run the whole data + ML pipeline in order:  python run_pipeline.py"""
import time

from src import build_db, explain, insights, segment, train

STEPS = [("1/5 Build SQL database", build_db.main),
         ("2/5 Train models (LogReg vs XGBoost)", train.main),
         ("3/5 SHAP explanations", explain.main),
         ("4/5 Segments + opportunities", segment.main),
         ("5/5 Insight documents for the assistant", insights.main)]

if __name__ == "__main__":
    t0 = time.time()
    for name, fn in STEPS:
        print(f"\n=== {name} ===")
        fn()
    print(f"\nDone in {time.time() - t0:.0f}s. Now run:  streamlit run app/dashboard.py")
