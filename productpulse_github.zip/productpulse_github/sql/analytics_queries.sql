-- =====================================================================
-- ProductPulse analytical queries (SQLite dialect)
-- Every query starts with "-- name:" - the dashboard and the AI assistant
-- load them by name (see src/db.py). Tables created by the pipeline:
--   customers, features, risk_scores, customer_explanations, shap_values,
--   segments, segment_profiles, opportunities, lift_table, feature_importance
-- =====================================================================

-- name: kpi_overview
-- desc: Headline KPIs - customers, churn rate, active MRR and lost MRR
SELECT COUNT(*)                                                        AS customers,
       SUM(churned)                                                    AS churned_customers,
       ROUND(100.0 * AVG(churned), 1)                                  AS churn_rate_pct,
       ROUND(SUM(CASE WHEN churned = 0 THEN monthly_charges END), 0)   AS active_mrr,
       ROUND(SUM(CASE WHEN churned = 1 THEN monthly_charges END), 0)   AS lost_mrr,
       ROUND(AVG(tenure_months), 1)                                    AS avg_tenure_months
FROM customers;

-- name: churn_by_contract
-- desc: Which contract type churns the most?
SELECT contract,
       COUNT(*)                          AS customers,
       SUM(churned)                      AS churned_customers,
       ROUND(100.0 * AVG(churned), 1)    AS churn_rate_pct,
       ROUND(AVG(monthly_charges), 2)    AS avg_monthly_charges
FROM customers
GROUP BY contract
ORDER BY churn_rate_pct DESC;

-- name: churn_by_tenure_band
-- desc: Churn rate by customer tenure band (early-life churn)
SELECT tenure_band,
       COUNT(*)                          AS customers,
       SUM(churned)                      AS churned_customers,
       ROUND(100.0 * AVG(churned), 1)    AS churn_rate_pct,
       MIN(tenure_months)                AS band_order
FROM customers
GROUP BY tenure_band
ORDER BY band_order;

-- name: churn_by_internet
-- desc: Churn by internet service type (DSL vs Fiber vs none)
SELECT internet_service,
       COUNT(*)                          AS customers,
       ROUND(100.0 * AVG(churned), 1)    AS churn_rate_pct,
       ROUND(AVG(monthly_charges), 2)    AS avg_monthly_charges
FROM customers
GROUP BY internet_service
ORDER BY churn_rate_pct DESC;

-- name: churn_by_payment
-- desc: Churn by payment method
SELECT payment_method,
       COUNT(*)                          AS customers,
       ROUND(100.0 * AVG(churned), 1)    AS churn_rate_pct
FROM customers
GROUP BY payment_method
ORDER BY churn_rate_pct DESC;

-- name: churn_by_senior
-- desc: Churn for senior citizens vs the rest
SELECT CASE WHEN senior_citizen = 'Yes' THEN 'Senior citizen' ELSE 'Not senior' END AS age_group,
       COUNT(*)                          AS customers,
       ROUND(100.0 * AVG(churned), 1)    AS churn_rate_pct
FROM customers
GROUP BY senior_citizen
ORDER BY churn_rate_pct DESC;

-- name: churn_by_monthly_charge
-- desc: Does a higher monthly bill increase churn? (price bands)
SELECT CASE WHEN monthly_charges < 35 THEN '1) Under $35'
            WHEN monthly_charges < 60 THEN '2) $35-60'
            WHEN monthly_charges < 85 THEN '3) $60-85'
            ELSE '4) $85+' END          AS price_band,
       COUNT(*)                         AS customers,
       ROUND(100.0 * AVG(churned), 1)   AS churn_rate_pct
FROM customers
GROUP BY price_band
ORDER BY price_band;

-- name: churn_by_contract_tenure
-- desc: Retention curve - churn by tenure band within each contract type
SELECT contract, tenure_band,
       COUNT(*)                          AS customers,
       ROUND(100.0 * AVG(churned), 1)    AS churn_rate_pct,
       MIN(tenure_months)                AS band_order
FROM customers
GROUP BY contract, tenure_band
ORDER BY contract, band_order;

-- name: churn_by_contract_payment
-- desc: Heatmap data - churn by contract x payment method
SELECT contract, payment_method,
       COUNT(*)                          AS customers,
       ROUND(100.0 * AVG(churned), 1)    AS churn_rate_pct
FROM customers
GROUP BY contract, payment_method;

-- name: addon_adoption_vs_churn
-- desc: Feature adoption vs churn for internet customers (adopters vs non-adopters)
SELECT 'Online Security' AS feature, online_security AS has_feature, COUNT(*) AS customers,
       ROUND(100.0 * AVG(churned), 1) AS churn_rate_pct
FROM customers WHERE internet_service <> 'No' GROUP BY online_security
UNION ALL
SELECT 'Online Backup', online_backup, COUNT(*), ROUND(100.0 * AVG(churned), 1)
FROM customers WHERE internet_service <> 'No' GROUP BY online_backup
UNION ALL
SELECT 'Device Protection', device_protection, COUNT(*), ROUND(100.0 * AVG(churned), 1)
FROM customers WHERE internet_service <> 'No' GROUP BY device_protection
UNION ALL
SELECT 'Tech Support', tech_support, COUNT(*), ROUND(100.0 * AVG(churned), 1)
FROM customers WHERE internet_service <> 'No' GROUP BY tech_support
UNION ALL
SELECT 'Streaming TV', streaming_tv, COUNT(*), ROUND(100.0 * AVG(churned), 1)
FROM customers WHERE internet_service <> 'No' GROUP BY streaming_tv
UNION ALL
SELECT 'Streaming Movies', streaming_movies, COUNT(*), ROUND(100.0 * AVG(churned), 1)
FROM customers WHERE internet_service <> 'No' GROUP BY streaming_movies;

-- name: top_churn_reasons
-- desc: Most common stated churn reasons with cumulative share (window functions)
WITH r AS (
    SELECT churn_reason, COUNT(*) AS customers_lost
    FROM customers
    WHERE churned = 1 AND churn_reason IS NOT NULL
    GROUP BY churn_reason
)
SELECT churn_reason,
       customers_lost,
       ROUND(100.0 * customers_lost / SUM(customers_lost) OVER (), 1) AS pct_of_churn,
       ROUND(100.0 * SUM(customers_lost) OVER (ORDER BY customers_lost DESC
             ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) / SUM(customers_lost) OVER (), 1) AS cumulative_pct
FROM r
ORDER BY customers_lost DESC
LIMIT 15;

-- name: avg_revenue_by_contract
-- desc: Average revenue per customer by contract
SELECT contract,
       ROUND(AVG(monthly_charges), 2)  AS avg_monthly_revenue,
       ROUND(AVG(total_charges), 0)    AS avg_lifetime_revenue,
       ROUND(AVG(tenure_months), 1)    AS avg_tenure_months
FROM customers
GROUP BY contract
ORDER BY avg_monthly_revenue DESC;

-- name: churn_by_segment
-- desc: Churn rate and active MRR by customer segment, ranked
SELECT s.segment,
       COUNT(*)                                                         AS customers,
       SUM(c.churned)                                                   AS churned_customers,
       ROUND(100.0 * AVG(c.churned), 1)                                 AS churn_rate_pct,
       ROUND(SUM(CASE WHEN c.churned = 0 THEN c.monthly_charges END), 0) AS active_mrr,
       RANK() OVER (ORDER BY AVG(c.churned) DESC)                       AS churn_rank
FROM customers c
JOIN segments s USING (customer_id)
GROUP BY s.segment
ORDER BY churn_rate_pct DESC;

-- name: mrr_at_risk_by_contract
-- desc: Monthly revenue of ACTIVE customers whose predicted churn risk is >= 50%
SELECT c.contract,
       COUNT(*)                                                         AS active_customers,
       SUM(CASE WHEN r.risk_score >= 0.5 THEN 1 ELSE 0 END)             AS high_risk_customers,
       ROUND(SUM(CASE WHEN r.risk_score >= 0.5 THEN c.monthly_charges ELSE 0 END), 0) AS mrr_at_risk
FROM customers c
JOIN risk_scores r USING (customer_id)
WHERE c.churned = 0
GROUP BY c.contract
ORDER BY mrr_at_risk DESC;

-- name: top_risk_customers
-- desc: Top N active customers most likely to churn, with reasons
SELECT e.customer_id,
       ROUND(e.risk_score, 3) AS risk_score,
       c.contract, c.tenure_months, c.monthly_charges,
       e.plain_text_reason
FROM customer_explanations e
JOIN customers c USING (customer_id)
WHERE c.churned = 0
ORDER BY e.risk_score DESC
LIMIT :n;

-- name: high_value_at_risk
-- desc: High-spending active customers (>= $80/mo) with high churn risk
SELECT e.customer_id,
       ROUND(e.risk_score, 3) AS risk_score,
       c.monthly_charges, c.contract, c.tenure_months,
       e.recommended_action
FROM customer_explanations e
JOIN customers c USING (customer_id)
WHERE c.churned = 0 AND c.monthly_charges >= 80 AND e.risk_score >= 0.5
ORDER BY c.monthly_charges * e.risk_score DESC
LIMIT 20;

-- name: active_risk_list
-- desc: Full ranked list of active customers with risk, segment and reason (used by dashboard)
SELECT e.customer_id,
       ROUND(e.risk_score, 4) AS risk_score,
       e.risk_band,
       s.segment,
       c.contract, c.internet_service, c.tenure_months, c.monthly_charges, c.annual_revenue,
       e.plain_text_reason, e.recommended_action
FROM customer_explanations e
JOIN customers c USING (customer_id)
JOIN segments s USING (customer_id)
WHERE c.churned = 0
ORDER BY e.risk_score DESC;

-- name: segment_points
-- desc: Customer-level points for the segment scatter plot
SELECT s.segment, c.tenure_months, c.monthly_charges, c.churned
FROM segments s JOIN customers c USING (customer_id);

-- name: customer_lookup
-- desc: Everything we know about one customer (risk, segment, reason, action)
SELECT c.customer_id,
       CASE WHEN c.churned = 1 THEN 'Churned' ELSE 'Active' END AS status,
       c.contract, c.internet_service, c.tenure_months, c.monthly_charges,
       ROUND(r.risk_score, 3) AS risk_score, r.risk_band,
       s.segment,
       e.plain_text_reason, e.protective_factor, e.recommended_action
FROM customers c
JOIN risk_scores r USING (customer_id)
JOIN segments s USING (customer_id)
JOIN customer_explanations e USING (customer_id)
WHERE c.customer_id = :cid;
